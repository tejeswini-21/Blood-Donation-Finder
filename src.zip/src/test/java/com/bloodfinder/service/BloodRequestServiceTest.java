package com.bloodfinder.service;

import com.bloodfinder.dto.BloodRequestDto;
import com.bloodfinder.entity.*;
import com.bloodfinder.enums.*;
import com.bloodfinder.exception.*;
import com.bloodfinder.repository.*;
import com.bloodfinder.service.impl.BloodRequestServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@DisplayName("Blood Request Lifecycle & Concurrency Service Tests")
class BloodRequestServiceTest {

    private BloodRequestRepository bloodRequestRepository;
    private DonationRecordRepository donationRecordRepository;
    private RequestResponseRepository requestResponseRepository;
    private DonorRepository donorRepository;
    private DonorService donorService;
    private NotificationService notificationService;
    private BloodRequestServiceImpl bloodRequestService;

    private User requester;
    private User donorUser;
    private Donor donor;

    @BeforeEach
    void setUp() {
        bloodRequestRepository = mock(BloodRequestRepository.class);
        donationRecordRepository = mock(DonationRecordRepository.class);
        requestResponseRepository = mock(RequestResponseRepository.class);
        donorRepository = mock(DonorRepository.class);
        donorService = mock(DonorService.class);
        notificationService = mock(NotificationService.class);

        bloodRequestService = new BloodRequestServiceImpl(
            bloodRequestRepository, donationRecordRepository, requestResponseRepository,
            donorRepository, donorService, notificationService
        );

        requester = new User("Requester Name", "requester@example.com", "9848011223", "hash", Role.REQUESTER, "Vijayawada", "Governorpet");
        requester.setId(10L);

        donorUser = new User("Donor Name", "donor@example.com", "9900112201", "hash", Role.DONOR, "Vijayawada", "Governorpet");
        donorUser.setId(20L);

        donor = new Donor(donorUser, BloodGroup.O_POS, 25, "Male", null, true);
        donor.setId(100L);
    }

    @Test
    @DisplayName("Should create blood request successfully when no duplicate exists")
    void testCreateRequestSuccess() {
        BloodRequestDto dto = new BloodRequestDto();
        dto.setPatientName("John Doe");
        dto.setBloodGroup(BloodGroup.O_POS);
        dto.setUnitsNeeded(2);
        dto.setHospitalName("City Care");
        dto.setCity("Vijayawada");
        dto.setUrgency(UrgencyLevel.EMERGENCY);
        dto.setRequiredBy(LocalDate.now().plusDays(2));
        dto.setContactNumber("9848011223");

        when(bloodRequestRepository.existsByRequesterAndPatientNameIgnoreCaseAndBloodGroupAndStatus(
            any(), any(), any(), eq(RequestStatus.OPEN)
        )).thenReturn(false);

        when(bloodRequestRepository.save(any(BloodRequest.class))).thenAnswer(i -> {
            BloodRequest req = i.getArgument(0);
            req.setId(1L);
            return req;
        });

        when(donorService.findEligibleDonors(any(), any(), any())).thenReturn(Collections.emptyList());

        BloodRequest created = bloodRequestService.createRequest(requester, dto);

        assertNotNull(created);
        assertEquals(1L, created.getId());
        assertEquals("John Doe", created.getPatientName());
        assertEquals(RequestStatus.OPEN, created.getStatus());
        verify(bloodRequestRepository).save(any(BloodRequest.class));
    }

    @Test
    @DisplayName("Should throw DuplicateRequestException when an open request exists for same patient and blood group")
    void testCreateDuplicateRequestThrowsException() {
        BloodRequestDto dto = new BloodRequestDto();
        dto.setPatientName("John Doe");
        dto.setBloodGroup(BloodGroup.O_POS);

        when(bloodRequestRepository.existsByRequesterAndPatientNameIgnoreCaseAndBloodGroupAndStatus(
            any(), any(), any(), eq(RequestStatus.OPEN)
        )).thenReturn(true);

        assertThrows(DuplicateRequestException.class, () -> bloodRequestService.createRequest(requester, dto));
        verify(bloodRequestRepository, never()).save(any(BloodRequest.class));
    }

    @Test
    @DisplayName("Should accept OPEN request and transition to ACCEPTED")
    void testAcceptRequestSuccess() {
        BloodRequest openRequest = new BloodRequest(requester, "Patient", BloodGroup.O_POS, 1, "Hospital", "Vijayawada", "Area", UrgencyLevel.NORMAL, LocalDate.now().plusDays(2), "9848011223", null);
        openRequest.setId(5L);
        openRequest.setStatus(RequestStatus.OPEN);

        when(donorService.isEligible(donor)).thenReturn(true);
        when(bloodRequestRepository.findById(5L)).thenReturn(Optional.of(openRequest));
        when(bloodRequestRepository.save(any())).thenAnswer(i -> i.getArgument(0));

        BloodRequest result = bloodRequestService.acceptRequest(5L, donor);

        assertEquals(RequestStatus.ACCEPTED, result.getStatus());
        assertEquals(donor, result.getAcceptedBy());
        verify(requestResponseRepository).save(any(RequestResponse.class));
        verify(notificationService, atLeastOnce()).sendNotification(any(), any(), any());
    }

    @Test
    @DisplayName("Should prevent double-acceptance if request status is already ACCEPTED")
    void testDoubleAcceptanceThrowsException() {
        BloodRequest acceptedRequest = new BloodRequest(requester, "Patient", BloodGroup.O_POS, 1, "Hospital", "Vijayawada", "Area", UrgencyLevel.NORMAL, LocalDate.now().plusDays(2), "9848011223", null);
        acceptedRequest.setId(5L);
        acceptedRequest.setStatus(RequestStatus.ACCEPTED); // already accepted

        when(donorService.isEligible(donor)).thenReturn(true);
        when(bloodRequestRepository.findById(5L)).thenReturn(Optional.of(acceptedRequest));

        IllegalStateException ex = assertThrows(IllegalStateException.class, () -> bloodRequestService.acceptRequest(5L, donor));
        assertTrue(ex.getMessage().contains("no longer open"));
        verify(bloodRequestRepository, never()).save(acceptedRequest);
    }

    @Test
    @DisplayName("Should prevent ineligible donor from accepting blood request")
    void testIneligibleDonorCannotAccept() {
        when(donorService.isEligible(donor)).thenReturn(false);

        assertThrows(DonorNotEligibleException.class, () -> bloodRequestService.acceptRequest(5L, donor));
        verify(bloodRequestRepository, never()).findById(any());
    }

    @Test
    @DisplayName("Should fulfill ACCEPTED request and log DonationRecord")
    void testFulfillRequestSuccess() {
        BloodRequest acceptedReq = new BloodRequest(requester, "Patient", BloodGroup.O_POS, 2, "Andhra Hospitals", "Vijayawada", "Area", UrgencyLevel.NORMAL, LocalDate.now().plusDays(2), "9848011223", null);
        acceptedReq.setId(7L);
        acceptedReq.setStatus(RequestStatus.ACCEPTED);
        acceptedReq.setAcceptedBy(donor);

        when(bloodRequestRepository.findById(7L)).thenReturn(Optional.of(acceptedReq));
        when(bloodRequestRepository.save(any())).thenAnswer(i -> i.getArgument(0));

        BloodRequest fulfilled = bloodRequestService.fulfillRequest(7L, requester, "Successful transfusion verified");

        assertEquals(RequestStatus.FULFILLED, fulfilled.getStatus());
        verify(donationRecordRepository).save(any(DonationRecord.class));
        verify(donorRepository).save(donor);
        assertEquals(1, donor.getTotalDonations());
        assertEquals(LocalDate.now(), donor.getLastDonationDate());
    }

    @Test
    @DisplayName("Should cancel OPEN request when requested by owner")
    void testCancelRequestSuccess() {
        BloodRequest openReq = new BloodRequest(requester, "Patient", BloodGroup.O_POS, 1, "Hospital", "Vijayawada", "Area", UrgencyLevel.NORMAL, LocalDate.now().plusDays(2), "9848011223", null);
        openReq.setId(8L);
        openReq.setStatus(RequestStatus.OPEN);

        when(bloodRequestRepository.findById(8L)).thenReturn(Optional.of(openReq));
        when(bloodRequestRepository.save(any())).thenAnswer(i -> i.getArgument(0));

        BloodRequest cancelled = bloodRequestService.cancelRequest(8L, requester);

        assertEquals(RequestStatus.CANCELLED, cancelled.getStatus());
    }

    @Test
    @DisplayName("Should throw UnauthorizedActionException when another user attempts to cancel a request")
    void testUnauthorizedUserCannotCancel() {
        BloodRequest openReq = new BloodRequest(requester, "Patient", BloodGroup.O_POS, 1, "Hospital", "Vijayawada", "Area", UrgencyLevel.NORMAL, LocalDate.now().plusDays(2), "9848011223", null);
        openReq.setId(8L);

        User anotherUser = new User("Intruder", "intruder@example.com", "9848999999", "hash", Role.REQUESTER, "Vijayawada", "Area");
        anotherUser.setId(99L);

        when(bloodRequestRepository.findById(8L)).thenReturn(Optional.of(openReq));

        assertThrows(UnauthorizedActionException.class, () -> bloodRequestService.cancelRequest(8L, anotherUser));
    }

    @Test
    @DisplayName("Should expire OPEN requests whose required-by date has passed")
    void testExpirePastRequests() {
        BloodRequest pastReq = new BloodRequest(requester, "Old Patient", BloodGroup.O_POS, 1, "Hospital", "Vijayawada", "Area", UrgencyLevel.NORMAL, LocalDate.now().minusDays(1), "9848011223", null);
        pastReq.setId(12L);
        pastReq.setStatus(RequestStatus.OPEN);

        when(bloodRequestRepository.findByStatusAndRequiredByBefore(eq(RequestStatus.OPEN), any(LocalDate.class)))
            .thenReturn(List.of(pastReq));

        int expiredCount = bloodRequestService.expirePastRequests();

        assertEquals(1, expiredCount);
        assertEquals(RequestStatus.EXPIRED, pastReq.getStatus());
        verify(bloodRequestRepository).save(pastReq);
    }
}
