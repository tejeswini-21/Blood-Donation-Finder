package com.bloodfinder.service;

import com.bloodfinder.entity.BloodBank;
import com.bloodfinder.entity.BloodStock;
import com.bloodfinder.enums.BloodGroup;
import com.bloodfinder.repository.BloodBankRepository;
import com.bloodfinder.repository.BloodStockRepository;
import com.bloodfinder.service.impl.BloodBankServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@DisplayName("Blood Bank & Stock Management Service Tests")
class BloodBankServiceTest {

    private BloodBankRepository bloodBankRepository;
    private BloodStockRepository bloodStockRepository;
    private BloodBankServiceImpl bloodBankService;
    private BloodBank bank;

    @BeforeEach
    void setUp() {
        bloodBankRepository = mock(BloodBankRepository.class);
        bloodStockRepository = mock(BloodStockRepository.class);
        bloodBankService = new BloodBankServiceImpl(bloodBankRepository, bloodStockRepository);

        bank = new BloodBank("City Care Blood Bank", "Vijayawada", "Suryaraopet", "0866-2431234", "Address", null, true);
        bank.setId(1L);
    }

    @Test
    @DisplayName("Should successfully update stock units for blood bank")
    void testUpdateStockSuccess() {
        BloodStock existingStock = new BloodStock(bank, BloodGroup.A_POS, 5);

        when(bloodBankRepository.findById(1L)).thenReturn(Optional.of(bank));
        when(bloodStockRepository.findByBloodBankAndBloodGroup(bank, BloodGroup.A_POS)).thenReturn(Optional.of(existingStock));
        when(bloodStockRepository.save(any(BloodStock.class))).thenAnswer(i -> i.getArgument(0));

        BloodStock updated = bloodBankService.updateStock(1L, BloodGroup.A_POS, 12);

        assertEquals(12, updated.getUnitsAvailable());
        assertFalse(updated.isLowStock());
        verify(bloodStockRepository).save(existingStock);
    }

    @Test
    @DisplayName("Should prevent updating stock with negative units")
    void testNegativeStockThrowsException() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () ->
            bloodBankService.updateStock(1L, BloodGroup.A_POS, -3)
        );
        assertTrue(ex.getMessage().contains("negative"));
        verify(bloodStockRepository, never()).save(any());
    }

    @Test
    @DisplayName("Stock below 5 units should trigger isLowStock flag")
    void testLowStockFlag() {
        BloodStock lowStock = new BloodStock(bank, BloodGroup.O_NEG, 3);
        assertTrue(lowStock.isLowStock());

        BloodStock normalStock = new BloodStock(bank, BloodGroup.O_POS, 8);
        assertFalse(normalStock.isLowStock());
    }

    @Test
    @DisplayName("Should toggle verification status of blood bank")
    void testVerifyBank() {
        when(bloodBankRepository.findById(1L)).thenReturn(Optional.of(bank));

        bloodBankService.verifyBank(1L, false);

        assertFalse(bank.isVerified());
        verify(bloodBankRepository).save(bank);
    }
}
