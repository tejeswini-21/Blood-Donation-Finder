package com.bloodfinder.service;

import com.bloodfinder.entity.Donor;
import com.bloodfinder.entity.User;
import com.bloodfinder.enums.BloodGroup;
import com.bloodfinder.enums.Role;
import com.bloodfinder.repository.DonorRepository;
import com.bloodfinder.service.impl.DonorServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Donor Eligibility Service Unit Tests")
class DonorEligibilityTest {

    private DonorServiceImpl donorService;
    private DonorRepository donorRepository;

    @BeforeEach
    void setUp() {
        donorRepository = Mockito.mock(DonorRepository.class);
        donorService = new DonorServiceImpl(donorRepository);
        donorService.setEligibilityDays(90); // Configurable 90-day assumption
    }

    private Donor createDonor(boolean enabled, boolean verified, boolean available, LocalDate lastDonationDate) {
        User user = new User("Test User", "test@example.com", "9848011223", "hash", Role.DONOR, "Vijayawada", "Governorpet");
        user.setEnabled(enabled);
        user.setVerified(verified);

        Donor donor = new Donor(user, BloodGroup.O_POS, 25, "Male", lastDonationDate, available);
        return donor;
    }

    @Test
    @DisplayName("First-time donor with no previous donation should be ELIGIBLE")
    void testFirstTimeDonorEligible() {
        Donor donor = createDonor(true, true, true, null);
        assertTrue(donorService.isEligible(donor));
        assertEquals(0, donorService.getDaysUntilEligible(donor));
        assertEquals(LocalDate.now(), donorService.calculateNextEligibilityDate(donor));
    }

    @Test
    @DisplayName("Donor who donated 30 days ago (< 90 days) should NOT be eligible")
    void testRecentDonationIneligible() {
        LocalDate lastDonation = LocalDate.now().minusDays(30);
        Donor donor = createDonor(true, true, true, lastDonation);

        assertFalse(donorService.isEligible(donor));
        assertEquals(60, donorService.getDaysUntilEligible(donor));
        assertEquals(lastDonation.plusDays(90), donorService.calculateNextEligibilityDate(donor));
    }

    @Test
    @DisplayName("Donor who donated exactly 90 days ago should be ELIGIBLE")
    void testExactly90DaysDonationEligible() {
        LocalDate lastDonation = LocalDate.now().minusDays(90);
        Donor donor = createDonor(true, true, true, lastDonation);

        assertTrue(donorService.isEligible(donor));
        assertEquals(0, donorService.getDaysUntilEligible(donor));
    }

    @Test
    @DisplayName("Donor who donated 120 days ago (> 90 days) should be ELIGIBLE")
    void testMoreThan90DaysEligible() {
        LocalDate lastDonation = LocalDate.now().minusDays(120);
        Donor donor = createDonor(true, true, true, lastDonation);

        assertTrue(donorService.isEligible(donor));
        assertEquals(0, donorService.getDaysUntilEligible(donor));
    }

    @Test
    @DisplayName("Donor marked as UNAVAILABLE should NOT be eligible even if donation date permits")
    void testUnavailableDonorIneligible() {
        Donor donor = createDonor(true, true, false, LocalDate.now().minusDays(120));
        assertFalse(donorService.isEligible(donor));
    }

    @Test
    @DisplayName("Donor with UNVERIFIED user account should NOT be eligible")
    void testUnverifiedDonorIneligible() {
        Donor donor = createDonor(true, false, true, LocalDate.now().minusDays(120));
        assertFalse(donorService.isEligible(donor));
    }

    @Test
    @DisplayName("Donor with DISABLED/BLOCKED account should NOT be eligible")
    void testDisabledDonorIneligible() {
        Donor donor = createDonor(false, true, true, LocalDate.now().minusDays(120));
        assertFalse(donorService.isEligible(donor));
    }

    @Test
    @DisplayName("Null donor should return false safely")
    void testNullDonorSafety() {
        assertFalse(donorService.isEligible(null));
    }
}
