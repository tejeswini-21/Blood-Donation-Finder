package com.bloodfinder.util;

import com.bloodfinder.enums.BloodGroup;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("BloodCompatibilityUtil Unit Tests")
class BloodCompatibilityUtilTest {

    @Test
    @DisplayName("A+ recipient should receive from A+, A-, O+, O-")
    void testAPositiveCompatibility() {
        Set<BloodGroup> donors = BloodCompatibilityUtil.getCompatibleDonors(BloodGroup.A_POS);
        assertEquals(4, donors.size());
        assertTrue(donors.contains(BloodGroup.A_POS));
        assertTrue(donors.contains(BloodGroup.A_NEG));
        assertTrue(donors.contains(BloodGroup.O_POS));
        assertTrue(donors.contains(BloodGroup.O_NEG));
        assertFalse(donors.contains(BloodGroup.B_POS));
        assertFalse(donors.contains(BloodGroup.AB_POS));

        assertTrue(BloodCompatibilityUtil.isCompatible(BloodGroup.A_POS, BloodGroup.A_POS));
        assertTrue(BloodCompatibilityUtil.isCompatible(BloodGroup.O_NEG, BloodGroup.A_POS));
        assertFalse(BloodCompatibilityUtil.isCompatible(BloodGroup.B_POS, BloodGroup.A_POS));
    }

    @Test
    @DisplayName("A- recipient should receive only from A- and O-")
    void testANegativeCompatibility() {
        Set<BloodGroup> donors = BloodCompatibilityUtil.getCompatibleDonors(BloodGroup.A_NEG);
        assertEquals(2, donors.size());
        assertTrue(donors.contains(BloodGroup.A_NEG));
        assertTrue(donors.contains(BloodGroup.O_NEG));
        assertFalse(donors.contains(BloodGroup.A_POS));
        assertFalse(donors.contains(BloodGroup.O_POS));

        assertTrue(BloodCompatibilityUtil.isCompatible(BloodGroup.A_NEG, BloodGroup.A_NEG));
        assertTrue(BloodCompatibilityUtil.isCompatible(BloodGroup.O_NEG, BloodGroup.A_NEG));
        assertFalse(BloodCompatibilityUtil.isCompatible(BloodGroup.A_POS, BloodGroup.A_NEG));
    }

    @Test
    @DisplayName("B+ recipient should receive from B+, B-, O+, O-")
    void testBPositiveCompatibility() {
        Set<BloodGroup> donors = BloodCompatibilityUtil.getCompatibleDonors(BloodGroup.B_POS);
        assertEquals(4, donors.size());
        assertTrue(donors.contains(BloodGroup.B_POS));
        assertTrue(donors.contains(BloodGroup.B_NEG));
        assertTrue(donors.contains(BloodGroup.O_POS));
        assertTrue(donors.contains(BloodGroup.O_NEG));
        assertFalse(donors.contains(BloodGroup.A_POS));

        assertTrue(BloodCompatibilityUtil.isCompatible(BloodGroup.B_POS, BloodGroup.B_POS));
        assertTrue(BloodCompatibilityUtil.isCompatible(BloodGroup.O_POS, BloodGroup.B_POS));
        assertFalse(BloodCompatibilityUtil.isCompatible(BloodGroup.A_NEG, BloodGroup.B_POS));
    }

    @Test
    @DisplayName("B- recipient should receive only from B- and O-")
    void testBNegativeCompatibility() {
        Set<BloodGroup> donors = BloodCompatibilityUtil.getCompatibleDonors(BloodGroup.B_NEG);
        assertEquals(2, donors.size());
        assertTrue(donors.contains(BloodGroup.B_NEG));
        assertTrue(donors.contains(BloodGroup.O_NEG));
        assertFalse(donors.contains(BloodGroup.B_POS));

        assertTrue(BloodCompatibilityUtil.isCompatible(BloodGroup.B_NEG, BloodGroup.B_NEG));
        assertTrue(BloodCompatibilityUtil.isCompatible(BloodGroup.O_NEG, BloodGroup.B_NEG));
        assertFalse(BloodCompatibilityUtil.isCompatible(BloodGroup.B_POS, BloodGroup.B_NEG));
    }

    @Test
    @DisplayName("AB+ recipient is Universal RBC Recipient and can receive from all 8 blood groups")
    void testABPositiveUniversalRecipient() {
        Set<BloodGroup> donors = BloodCompatibilityUtil.getCompatibleDonors(BloodGroup.AB_POS);
        assertEquals(8, donors.size());
        for (BloodGroup bg : BloodGroup.values()) {
            assertTrue(donors.contains(bg));
            assertTrue(BloodCompatibilityUtil.isCompatible(bg, BloodGroup.AB_POS));
        }
    }

    @Test
    @DisplayName("AB- recipient should receive from AB-, A-, B-, O-")
    void testABNegativeCompatibility() {
        Set<BloodGroup> donors = BloodCompatibilityUtil.getCompatibleDonors(BloodGroup.AB_NEG);
        assertEquals(4, donors.size());
        assertTrue(donors.contains(BloodGroup.AB_NEG));
        assertTrue(donors.contains(BloodGroup.A_NEG));
        assertTrue(donors.contains(BloodGroup.B_NEG));
        assertTrue(donors.contains(BloodGroup.O_NEG));
        assertFalse(donors.contains(BloodGroup.AB_POS));
        assertFalse(donors.contains(BloodGroup.A_POS));
        assertFalse(donors.contains(BloodGroup.B_POS));
        assertFalse(donors.contains(BloodGroup.O_POS));
    }

    @Test
    @DisplayName("O+ recipient should receive from O+ and O-")
    void testOPositiveCompatibility() {
        Set<BloodGroup> donors = BloodCompatibilityUtil.getCompatibleDonors(BloodGroup.O_POS);
        assertEquals(2, donors.size());
        assertTrue(donors.contains(BloodGroup.O_POS));
        assertTrue(donors.contains(BloodGroup.O_NEG));
        assertFalse(donors.contains(BloodGroup.A_POS));
        assertFalse(donors.contains(BloodGroup.B_POS));
    }

    @Test
    @DisplayName("O- recipient can receive red blood cells ONLY from O-")
    void testONegativeUniversalDonor() {
        Set<BloodGroup> donors = BloodCompatibilityUtil.getCompatibleDonors(BloodGroup.O_NEG);
        assertEquals(1, donors.size());
        assertTrue(donors.contains(BloodGroup.O_NEG));
        assertFalse(donors.contains(BloodGroup.O_POS));

        // Verify O- is compatible with ALL recipients
        for (BloodGroup recipient : BloodGroup.values()) {
            assertTrue(BloodCompatibilityUtil.isCompatible(BloodGroup.O_NEG, recipient));
        }
    }

    @Test
    @DisplayName("Null handling should return empty set or false safely")
    void testNullSafety() {
        assertTrue(BloodCompatibilityUtil.getCompatibleDonors(null).isEmpty());
        assertFalse(BloodCompatibilityUtil.isCompatible(null, BloodGroup.A_POS));
        assertFalse(BloodCompatibilityUtil.isCompatible(BloodGroup.A_POS, null));
        assertFalse(BloodCompatibilityUtil.isCompatible(null, null));
    }
}
