package com.bloodfinder;

import com.bloodfinder.enums.Role;
import com.bloodfinder.repository.UserRepository;
import com.bloodfinder.service.BloodRequestService;
import com.bloodfinder.service.DonorService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("h2")
@DisplayName("Spring Boot Application Context & DataSeeder Integration Tests")
class BloodDonationApplicationTests {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private DonorService donorService;

    @Autowired
    private BloodRequestService bloodRequestService;

    @Test
    @DisplayName("Application context loads and seeds default admin and sample data")
    void contextLoadsAndDataSeederExecutes() {
        assertNotNull(userRepository);
        assertNotNull(donorService);
        assertNotNull(bloodRequestService);

        // Verify default admin was seeded
        assertTrue(userRepository.findByEmail("admin@bloodfinder.com").isPresent(),
            "Default admin should be seeded on startup");

        // Verify donors were seeded
        assertTrue(donorService.getTotalDonorCount() >= 15,
            "At least 15 sample donors should be seeded");

        // Verify requests were seeded
        assertTrue(bloodRequestService.getTotalRequestCount() >= 5,
            "At least 5 sample blood requests should be seeded");
    }
}
