package com.bloodfinder.security;

import com.bloodfinder.entity.User;
import com.bloodfinder.enums.Role;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Collection;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Spring Security & Access Control Unit Tests")
class SecurityTest {

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Test
    @DisplayName("BCrypt password encoder should generate secure salt and hash")
    void testBCryptPasswordHashing() {
        String rawPassword = "SecurePassword@123";
        String encodedHash = passwordEncoder.encode(rawPassword);

        assertNotNull(encodedHash);
        assertNotEquals(rawPassword, encodedHash);
        assertTrue(passwordEncoder.matches(rawPassword, encodedHash));
        assertFalse(passwordEncoder.matches("WrongPassword", encodedHash));
    }

    @Test
    @DisplayName("CustomUserDetails should properly assign ROLE_ prefix to user role")
    void testRoleAuthoritiesMapping() {
        User donorUser = new User("Donor", "donor@example.com", "9848011223", "hash", Role.DONOR, "Vijayawada", null);
        CustomUserDetails donorDetails = new CustomUserDetails(donorUser);

        Collection<? extends GrantedAuthority> authorities = donorDetails.getAuthorities();
        assertEquals(1, authorities.size());
        assertEquals("ROLE_DONOR", authorities.iterator().next().getAuthority());

        User adminUser = new User("Admin", "admin@example.com", "9848011223", "hash", Role.ADMIN, "Vijayawada", null);
        CustomUserDetails adminDetails = new CustomUserDetails(adminUser);
        assertEquals("ROLE_ADMIN", adminDetails.getAuthorities().iterator().next().getAuthority());
    }

    @Test
    @DisplayName("Blocked user (enabled=false) should be locked in CustomUserDetails")
    void testBlockedUserLockedOut() {
        User blockedUser = new User("Blocked", "blocked@example.com", "9848011223", "hash", Role.DONOR, "Vijayawada", null);
        blockedUser.setEnabled(false);

        CustomUserDetails details = new CustomUserDetails(blockedUser);
        assertFalse(details.isEnabled());
        assertFalse(details.isAccountNonLocked());

        User activeUser = new User("Active", "active@example.com", "9848011223", "hash", Role.DONOR, "Vijayawada", null);
        activeUser.setEnabled(true);

        activeUser.setVerified(true);
        CustomUserDetails activeDetails = new CustomUserDetails(activeUser);
        assertTrue(activeDetails.isEnabled());
        assertTrue(activeDetails.isAccountNonLocked());

        User unverified = new User("Pending", "pending@example.com", "9848011223", "hash", Role.HOSPITAL, "Vijayawada", null);
        unverified.setEnabled(true);
        unverified.setVerified(false);
        CustomUserDetails pendingDetails = new CustomUserDetails(unverified);
        assertFalse(pendingDetails.isEnabled(), "Unverified accounts must not be allowed to log in");
        assertTrue(pendingDetails.isAccountNonLocked());
    }
}
