package com.bloodfinder.dto;

import com.bloodfinder.enums.BloodGroup;

public class DonorSearchDto {

    private BloodGroup bloodGroup;
    private String city;
    private String area;

    public DonorSearchDto() {
    }

    public DonorSearchDto(BloodGroup bloodGroup, String city, String area) {
        this.bloodGroup = bloodGroup;
        this.city = city;
        this.area = area;
    }

    public BloodGroup getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(BloodGroup bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
}
