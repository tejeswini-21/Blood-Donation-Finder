package com.bloodfinder.dto;

import com.bloodfinder.enums.BloodGroup;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class StockUpdateDto {

    @NotNull
    private Long bloodBankId;

    @NotNull(message = "Blood group is required")
    private BloodGroup bloodGroup;

    @NotNull(message = "Units count is required")
    @Min(value = 0, message = "Available units cannot be negative")
    private Integer units = 0;

    public StockUpdateDto() {
    }

    public StockUpdateDto(Long bloodBankId, BloodGroup bloodGroup, Integer units) {
        this.bloodBankId = bloodBankId;
        this.bloodGroup = bloodGroup;
        this.units = units;
    }

    public Long getBloodBankId() {
        return bloodBankId;
    }

    public void setBloodBankId(Long bloodBankId) {
        this.bloodBankId = bloodBankId;
    }

    public BloodGroup getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(BloodGroup bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public Integer getUnits() {
        return units;
    }

    public void setUnits(Integer units) {
        this.units = units;
    }
}
