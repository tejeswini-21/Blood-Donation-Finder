package com.bloodfinder.dto;

import java.util.Map;

public class AdminDashboardDto {

    private long totalUsers;
    private long totalDonors;
    private long totalRequesters;
    private long totalHospitals;
    private long totalRequests;
    private long emergencyRequests;
    private long fulfilledRequests;
    private long pendingVerifications;
    private long totalUnitsInStock;

    private Map<String, Long> donorsPerBloodGroup;
    private Map<String, Long> requestsPerCity;
    private Map<String, Long> requestsByStatus;

    public AdminDashboardDto() {
    }

    // Getters and Setters
    public long getTotalUsers() {
        return totalUsers;
    }

    public void setTotalUsers(long totalUsers) {
        this.totalUsers = totalUsers;
    }

    public long getTotalDonors() {
        return totalDonors;
    }

    public void setTotalDonors(long totalDonors) {
        this.totalDonors = totalDonors;
    }

    public long getTotalRequesters() {
        return totalRequesters;
    }

    public void setTotalRequesters(long totalRequesters) {
        this.totalRequesters = totalRequesters;
    }

    public long getTotalHospitals() {
        return totalHospitals;
    }

    public void setTotalHospitals(long totalHospitals) {
        this.totalHospitals = totalHospitals;
    }

    public long getTotalRequests() {
        return totalRequests;
    }

    public void setTotalRequests(long totalRequests) {
        this.totalRequests = totalRequests;
    }

    public long getEmergencyRequests() {
        return emergencyRequests;
    }

    public void setEmergencyRequests(long emergencyRequests) {
        this.emergencyRequests = emergencyRequests;
    }

    public long getFulfilledRequests() {
        return fulfilledRequests;
    }

    public void setFulfilledRequests(long fulfilledRequests) {
        this.fulfilledRequests = fulfilledRequests;
    }

    public long getPendingVerifications() {
        return pendingVerifications;
    }

    public void setPendingVerifications(long pendingVerifications) {
        this.pendingVerifications = pendingVerifications;
    }

    public long getTotalUnitsInStock() {
        return totalUnitsInStock;
    }

    public void setTotalUnitsInStock(long totalUnitsInStock) {
        this.totalUnitsInStock = totalUnitsInStock;
    }

    public Map<String, Long> getDonorsPerBloodGroup() {
        return donorsPerBloodGroup;
    }

    public void setDonorsPerBloodGroup(Map<String, Long> donorsPerBloodGroup) {
        this.donorsPerBloodGroup = donorsPerBloodGroup;
    }

    public Map<String, Long> getRequestsPerCity() {
        return requestsPerCity;
    }

    public void setRequestsPerCity(Map<String, Long> requestsPerCity) {
        this.requestsPerCity = requestsPerCity;
    }

    public Map<String, Long> getRequestsByStatus() {
        return requestsByStatus;
    }

    public void setRequestsByStatus(Map<String, Long> requestsByStatus) {
        this.requestsByStatus = requestsByStatus;
    }
}
