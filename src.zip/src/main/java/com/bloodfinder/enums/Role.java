package com.bloodfinder.enums;

public enum Role {
    DONOR("Donor"),
    REQUESTER("Recipient / Requester"),
    HOSPITAL("Hospital / Blood Bank"),
    ADMIN("Administrator");

    private final String displayName;

    Role(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
