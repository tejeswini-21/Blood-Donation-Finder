package com.bloodfinder.enums;

public enum BloodGroup {
    A_POS("A+"),
    A_NEG("A-"),
    B_POS("B+"),
    B_NEG("B-"),
    AB_POS("AB+"),
    AB_NEG("AB-"),
    O_POS("O+"),
    O_NEG("O-");

    private final String label;

    BloodGroup(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    public static BloodGroup fromLabel(String label) {
        if (label == null) return null;
        String trimmed = label.trim().toUpperCase();
        for (BloodGroup bg : values()) {
            if (bg.label.equalsIgnoreCase(trimmed) || bg.name().equalsIgnoreCase(trimmed)) {
                return bg;
            }
        }
        throw new IllegalArgumentException("Unknown blood group: " + label);
    }
}
