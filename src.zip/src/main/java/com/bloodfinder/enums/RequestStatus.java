package com.bloodfinder.enums;

public enum RequestStatus {
    OPEN("Open", "primary"),
    ACCEPTED("Accepted", "info"),
    FULFILLED("Fulfilled", "success"),
    CANCELLED("Cancelled", "secondary"),
    EXPIRED("Expired", "dark");

    private final String displayName;
    private final String badgeClass;

    RequestStatus(String displayName, String badgeClass) {
        this.displayName = displayName;
        this.badgeClass = badgeClass;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getBadgeClass() {
        return badgeClass;
    }
}
