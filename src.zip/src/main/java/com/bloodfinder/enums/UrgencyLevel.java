package com.bloodfinder.enums;

public enum UrgencyLevel {
    NORMAL("Normal", "info"),
    URGENT("Urgent", "warning"),
    EMERGENCY("Critical Emergency", "danger");

    private final String displayName;
    private final String badgeClass;

    UrgencyLevel(String displayName, String badgeClass) {
        this.displayName = displayName;
        this.badgeClass = badgeClass;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getBadgeClass() {
        return badgeClass;
    }
}
