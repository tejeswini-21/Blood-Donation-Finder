package com.bloodfinder.config;

import com.bloodfinder.entity.*;
import com.bloodfinder.enums.*;
import com.bloodfinder.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Component
public class DataSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);

    private final UserRepository userRepository;
    private final DonorRepository donorRepository;
    private final BloodBankRepository bloodBankRepository;
    private final BloodStockRepository bloodStockRepository;
    private final BloodRequestRepository bloodRequestRepository;
    private final DonationRecordRepository donationRecordRepository;
    private final NotificationRepository notificationRepository;
    private final RequestResponseRepository requestResponseRepository;
    private final PasswordEncoder passwordEncoder;

    public DataSeeder(UserRepository userRepository,
                      DonorRepository donorRepository,
                      BloodBankRepository bloodBankRepository,
                      BloodStockRepository bloodStockRepository,
                      BloodRequestRepository bloodRequestRepository,
                      DonationRecordRepository donationRecordRepository,
                      NotificationRepository notificationRepository,
                      RequestResponseRepository requestResponseRepository,
                      PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.donorRepository = donorRepository;
        this.bloodBankRepository = bloodBankRepository;
        this.bloodStockRepository = bloodStockRepository;
        this.bloodRequestRepository = bloodRequestRepository;
        this.donationRecordRepository = donationRecordRepository;
        this.notificationRepository = notificationRepository;
        this.requestResponseRepository = requestResponseRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (userRepository.count() > 0) {
            log.info("Database already contains data. Skipping sample data seeding.");
            return;
        }

        log.info("Starting sample data seeding for Blood Donation System (Demo Mode)...");

        // 1. Create Default Admin
        String defaultPasswordHash = passwordEncoder.encode("Admin@123");
        User admin = new User("System Administrator", "admin@bloodfinder.com", "9876543210", defaultPasswordHash, Role.ADMIN, "Vijayawada", "Governorpet");
        admin.setVerified(true);
        admin.setEnabled(true);
        userRepository.save(admin);
        log.info("Default Admin created: admin@bloodfinder.com / Admin@123");

        // 2. Create Requesters (Recipients)
        String userPassHash = passwordEncoder.encode("User@123");
        User req1 = new User("Ravi Kumar (Demo)", "ravi.recipient@example.com", "9848011223", userPassHash, Role.REQUESTER, "Vijayawada", "Bhavanipuram");
        req1.setVerified(true);
        userRepository.save(req1);

        User req2 = new User("Sunita Reddy (Demo)", "sunita.recipient@example.com", "9848022334", userPassHash, Role.REQUESTER, "Hyderabad", "Banjara Hills");
        req2.setVerified(true);
        userRepository.save(req2);

        User req3 = new User("Venkat Rao (Demo)", "venkat.recipient@example.com", "9848033445", userPassHash, Role.REQUESTER, "Visakhapatnam", "MVP Colony");
        req3.setVerified(true);
        userRepository.save(req3);

        // 3. Create 3 Hospital/Blood Bank users and their BloodBanks
        String hospPassHash = passwordEncoder.encode("Hospital@123");

        // Hospital 1 - Vijayawada
        User hospUser1 = new User("City Care Hospital & Blood Centre", "citycare.vja@example.com", "9848123456", hospPassHash, Role.HOSPITAL, "Vijayawada", "Suryaraopet");
        hospUser1.setVerified(true);
        userRepository.save(hospUser1);
        BloodBank bank1 = new BloodBank("City Care Regional Blood Centre", "Vijayawada", "Suryaraopet", "0866-2431234", "Beside Old Bus Stand, Suryaraopet, Vijayawada", hospUser1, true);
        bloodBankRepository.save(bank1);

        // Hospital 2 - Hyderabad
        User hospUser2 = new User("Apollo Red Cross Blood Centre", "redcross.hyd@example.com", "9848234567", hospPassHash, Role.HOSPITAL, "Hyderabad", "Jubilee Hills");
        hospUser2.setVerified(true);
        userRepository.save(hospUser2);
        BloodBank bank2 = new BloodBank("Apollo Red Cross Central Bank", "Hyderabad", "Jubilee Hills", "040-23607777", "Road No 36, Jubilee Hills, Hyderabad", hospUser2, true);
        bloodBankRepository.save(bank2);

        // Hospital 3 - Visakhapatnam
        User hospUser3 = new User("Coastal Life Blood Institute", "coastallife.vzg@example.com", "9848345678", hospPassHash, Role.HOSPITAL, "Visakhapatnam", "Maharanipeta");
        hospUser3.setVerified(true);
        userRepository.save(hospUser3);
        BloodBank bank3 = new BloodBank("Coastal Life Trust Blood Bank", "Visakhapatnam", "Maharanipeta", "0891-2567890", "Opposite KGH, Maharanipeta, Visakhapatnam", hospUser3, true);
        bloodBankRepository.save(bank3);

        // Seed stock for each blood bank across all 8 blood groups
        seedStockForBank(bank1, new int[]{12, 4, 15, 3, 8, 2, 20, 6}); // notice some low stocks (< 5)
        seedStockForBank(bank2, new int[]{25, 8, 30, 5, 14, 4, 35, 10});
        seedStockForBank(bank3, new int[]{6, 2, 9, 1, 5, 0, 15, 3});

        // 4. Create 15 Sample Donors
        // Across Vijayawada, Guntur, Hyderabad, Visakhapatnam
        // Mixed blood groups, varied donation dates, verified/unverified/unavailable
        List<DonorSeedData> donorSeedList = Arrays.asList(
            new DonorSeedData("Kiran Varma", "kiran.a_pos@example.com", "9900112201", "Vijayawada", "Governorpet", BloodGroup.A_POS, 26, "Male", LocalDate.now().minusDays(120), true, true, true, 4),
            new DonorSeedData("Ananya Sharma", "ananya.o_pos@example.com", "9900112202", "Vijayawada", "Benz Circle", BloodGroup.O_POS, 24, "Female", null, true, true, true, 0),
            new DonorSeedData("Suresh Naidu", "suresh.b_pos@example.com", "9900112203", "Vijayawada", "Gollapudi", BloodGroup.B_POS, 32, "Male", LocalDate.now().minusDays(30), true, true, true, 2), // <90 days: NOT eligible
            new DonorSeedData("Pooja Hegde", "pooja.ab_pos@example.com", "9900112204", "Vijayawada", "Gunadala", BloodGroup.AB_POS, 22, "Female", LocalDate.now().minusDays(95), false, true, true, 1), // Unavailable
            new DonorSeedData("Madhav Krishna", "madhav.o_neg@example.com", "9900112205", "Guntur", "Brodipet", BloodGroup.O_NEG, 29, "Male", LocalDate.now().minusDays(110), true, true, true, 5), // Universal donor
            new DonorSeedData("Lakshmi Prasanna", "lakshmi.a_neg@example.com", "9900112206", "Guntur", "Arundelpet", BloodGroup.A_NEG, 28, "Female", null, true, false, true, 0), // Unverified
            new DonorSeedData("Ramesh Chander", "ramesh.b_neg@example.com", "9900112207", "Guntur", "Nallapadu", BloodGroup.B_NEG, 35, "Male", LocalDate.now().minusDays(150), true, true, true, 3),
            new DonorSeedData("Deepika Roy", "deepika.ab_neg@example.com", "9900112208", "Hyderabad", "Madhapur", BloodGroup.AB_NEG, 27, "Female", LocalDate.now().minusDays(180), true, true, true, 2),
            new DonorSeedData("Sai Charan", "sai.o_pos@example.com", "9900112209", "Hyderabad", "Kondapur", BloodGroup.O_POS, 30, "Male", LocalDate.now().minusDays(90), true, true, true, 3), // Exactly 90 days: ELIGIBLE
            new DonorSeedData("Harika G", "harika.a_pos@example.com", "9900112210", "Hyderabad", "Gachibowli", BloodGroup.A_POS, 25, "Female", LocalDate.now().minusDays(45), true, true, true, 1), // <90 days
            new DonorSeedData("Vikram Rathod", "vikram.b_pos@example.com", "9900112211", "Hyderabad", "Kukatpally", BloodGroup.B_POS, 38, "Male", LocalDate.now().minusDays(200), true, true, true, 6),
            new DonorSeedData("Praveen Teja", "praveen.o_pos@example.com", "9900112212", "Visakhapatnam", "Gajuwaka", BloodGroup.O_POS, 31, "Male", LocalDate.now().minusDays(100), true, true, true, 2),
            new DonorSeedData("Sneha Latha", "sneha.a_pos@example.com", "9900112213", "Visakhapatnam", "Siripuram", BloodGroup.A_POS, 23, "Female", null, true, true, true, 0),
            new DonorSeedData("Rohit Varma", "rohit.b_pos@example.com", "9900112214", "Visakhapatnam", "MVP Colony", BloodGroup.B_POS, 27, "Male", LocalDate.now().minusDays(140), true, true, true, 1),
            new DonorSeedData("Tarun Das", "tarun.ab_pos@example.com", "9900112215", "Visakhapatnam", "Pendurthi", BloodGroup.AB_POS, 34, "Male", LocalDate.now().minusDays(15), true, true, false, 2) // Disabled
        );

        Map<String, Donor> donorMap = new HashMap<>();
        String donorPasswordHash = passwordEncoder.encode("Donor@123");

        for (DonorSeedData d : donorSeedList) {
            User u = new User(d.name + " (Demo)", d.email, d.phone, donorPasswordHash, Role.DONOR, d.city, d.area);
            u.setVerified(d.verified);
            u.setEnabled(d.enabled);
            userRepository.save(u);

            Donor donor = new Donor(u, d.bloodGroup, d.age, d.gender, d.lastDonationDate, d.available);
            donor.setTotalDonations(d.totalDonations);
            donorRepository.save(donor);
            donorMap.put(d.email, donor);
        }
        donorRepository.flush();

        // 5. Create 5 Sample Blood Requests with different statuses
        // Request 1: EMERGENCY, OPEN in Vijayawada (Looking for O+ or compatible)
        BloodRequest reqOpenEmergency = new BloodRequest(
            req1, "Rajesh Babu (Cardiac Surgery)", BloodGroup.O_POS, 2,
            "Manipal Hospital, Vijayawada", "Vijayawada", "Tadepalli",
            UrgencyLevel.EMERGENCY, LocalDate.now().plusDays(2), "9848011223",
            "Urgent requirement for bypass procedure. Immediate blood needed."
        );
        reqOpenEmergency.setStatus(RequestStatus.OPEN);
        reqOpenEmergency = bloodRequestRepository.save(reqOpenEmergency);

        // Request 2: URGENT, OPEN in Hyderabad (Looking for A+ or compatible)
        BloodRequest reqOpenUrgent = new BloodRequest(
            req2, "Priya Sharma (Severe Anemia)", BloodGroup.A_POS, 1,
            "KIMS Hospital, Secunderabad", "Hyderabad", "Begumpet",
            UrgencyLevel.URGENT, LocalDate.now().plusDays(3), "9848022334",
            "Patient hemoglobin level critical, transfusion required within 24 hours."
        );
        reqOpenUrgent.setStatus(RequestStatus.OPEN);
        reqOpenUrgent = bloodRequestRepository.save(reqOpenUrgent);

        // Request 3: ACCEPTED in Vijayawada by Kiran Varma
        Donor kiran = donorMap.get("kiran.a_pos@example.com");
        BloodRequest reqAccepted = new BloodRequest(
            req1, "Anand Mohan (Orthopedic Trauma)", BloodGroup.A_POS, 1,
            "Andhra Hospitals, Vijayawada", "Vijayawada", "Governorpet",
            UrgencyLevel.NORMAL, LocalDate.now().plusDays(4), "9848011223",
            "Scheduled knee replacement surgery, donor accepted."
        );
        reqAccepted.setStatus(RequestStatus.ACCEPTED);
        reqAccepted.setAcceptedBy(kiran);
        reqAccepted = bloodRequestRepository.save(reqAccepted);

        // Request 4: FULFILLED in Visakhapatnam by Praveen Teja
        Donor praveen = donorMap.get("praveen.o_pos@example.com");
        BloodRequest reqFulfilled = new BloodRequest(
            req3, "Kavita Rao (Maternity Ward)", BloodGroup.O_POS, 2,
            "King George Hospital (KGH)", "Visakhapatnam", "Maharanipeta",
            UrgencyLevel.URGENT, LocalDate.now().minusDays(5), "9848033445",
            "Donation completed successfully. Transfusion verified by hospital staff."
        );
        reqFulfilled.setStatus(RequestStatus.FULFILLED);
        reqFulfilled.setAcceptedBy(praveen);
        reqFulfilled = bloodRequestRepository.save(reqFulfilled);

        // Request 5: CANCELLED request
        BloodRequest reqCancelled = new BloodRequest(
            req2, "Vamsi Krishna (Post-Op Observation)", BloodGroup.B_POS, 1,
            "Yashoda Hospital, Somajiguda", "Hyderabad", "Somajiguda",
            UrgencyLevel.NORMAL, LocalDate.now().minusDays(2), "9848022334",
            "Patient discharged early, requirement cancelled by family."
        );
        reqCancelled.setStatus(RequestStatus.CANCELLED);
        reqCancelled = bloodRequestRepository.save(reqCancelled);
        bloodRequestRepository.flush();

        // Historical walk-in donations are stored without a BloodRequest (nullable FK).
        // Persist them only after donors are flushed so the donor side is managed.
        for (Donor donor : donorMap.values()) {
            if (donor.getLastDonationDate() == null) {
                continue;
            }
            DonationRecord historical = new DonationRecord();
            historical.setDonor(donor);
            historical.setRequest(null);
            historical.setDonationDate(donor.getLastDonationDate());
            historical.setUnits(1);
            historical.setHospital("Government General Hospital, " + donor.getUser().getCity());
            historical.setRemarks("Demo historical walk-in donation (not linked to an in-app request)");
            donationRecordRepository.save(historical);
        }

        // Fulfilment donation is linked to the already-persisted request
        DonationRecord fulfilledRec = new DonationRecord();
        fulfilledRec.setDonor(praveen);
        fulfilledRec.setRequest(reqFulfilled);
        fulfilledRec.setDonationDate(LocalDate.now().minusDays(5));
        fulfilledRec.setUnits(2);
        fulfilledRec.setHospital("King George Hospital (KGH)");
        fulfilledRec.setRemarks("Emergency Caesarean Transfusion");
        donationRecordRepository.save(fulfilledRec);
        donationRecordRepository.flush();

        requestResponseRepository.save(new RequestResponse(reqAccepted, kiran, "ACCEPTED"));
        requestResponseRepository.save(new RequestResponse(reqFulfilled, praveen, "ACCEPTED"));

        // Create in-app notifications
        notificationRepository.save(new Notification(kiran.getUser(), "You have accepted blood request #" + reqAccepted.getId() + " for patient Anand Mohan. Please reach Andhra Hospitals.", "/donor/requests"));
        notificationRepository.save(new Notification(req1, "Donor Kiran Varma has accepted your blood request #" + reqAccepted.getId() + "!", "/requester/requests"));
        notificationRepository.save(new Notification(admin, "New Emergency blood request raised in Vijayawada for patient Rajesh Babu (O+)", "/admin/requests"));

        log.info("Sample data seeding completed successfully! Total Donors: 15, Blood Banks: 3, Requests: 5.");
    }

    private void seedStockForBank(BloodBank bank, int[] units) {
        BloodGroup[] groups = BloodGroup.values();
        for (int i = 0; i < groups.length; i++) {
            int count = (i < units.length) ? units[i] : 5;
            BloodStock stock = new BloodStock(bank, groups[i], count);
            bloodStockRepository.save(stock);
        }
    }

    private static class DonorSeedData {
        String name;
        String email;
        String phone;
        String city;
        String area;
        BloodGroup bloodGroup;
        int age;
        String gender;
        LocalDate lastDonationDate;
        boolean available;
        boolean verified;
        boolean enabled;
        int totalDonations;

        DonorSeedData(String name, String email, String phone, String city, String area,
                      BloodGroup bloodGroup, int age, String gender, LocalDate lastDonationDate,
                      boolean available, boolean verified, boolean enabled, int totalDonations) {
            this.name = name;
            this.email = email;
            this.phone = phone;
            this.city = city;
            this.area = area;
            this.bloodGroup = bloodGroup;
            this.age = age;
            this.gender = gender;
            this.lastDonationDate = lastDonationDate;
            this.available = available;
            this.verified = verified;
            this.enabled = enabled;
            this.totalDonations = totalDonations;
        }
    }
}
