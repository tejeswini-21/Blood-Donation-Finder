package com.bloodfinder.controller;

import com.bloodfinder.dto.AdminDashboardDto;
import com.bloodfinder.entity.BloodBank;
import com.bloodfinder.entity.BloodRequest;
import com.bloodfinder.entity.Donor;
import com.bloodfinder.entity.User;
import com.bloodfinder.enums.Role;
import com.bloodfinder.service.*;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final AdminService adminService;
    private final UserService userService;
    private final DonorService donorService;
    private final BloodRequestService bloodRequestService;
    private final BloodBankService bloodBankService;

    public AdminController(AdminService adminService,
                           UserService userService,
                           DonorService donorService,
                           BloodRequestService bloodRequestService,
                           BloodBankService bloodBankService) {
        this.adminService = adminService;
        this.userService = userService;
        this.donorService = donorService;
        this.bloodRequestService = bloodRequestService;
        this.bloodBankService = bloodBankService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        AdminDashboardDto stats = adminService.getDashboardStats();
        model.addAttribute("stats", stats);
        model.addAttribute("recentRequests", bloodRequestService.getAllRequests().stream().limit(6).toList());
        model.addAttribute("pendingVerifications", userService.getPendingVerifications());
        return "admin/dashboard";
    }

    @GetMapping("/donors")
    public String manageDonors(Model model) {
        List<Donor> donors = donorService.getAllDonors();
        model.addAttribute("donors", donors);
        return "admin/manage-donors";
    }

    @GetMapping("/users")
    public String manageUsers(Model model) {
        List<User> users = userService.getAllUsers();
        model.addAttribute("users", users);
        return "admin/manage-users";
    }

    @PostMapping("/users/{id}/toggle-status")
    public String toggleUserStatus(@PathVariable("id") Long id,
                                   @RequestParam("enabled") boolean enabled,
                                   RedirectAttributes redirectAttributes) {
        userService.toggleUserStatus(id, enabled);
        String msg = enabled ? "User account unblocked/enabled." : "User account blocked.";
        redirectAttributes.addFlashAttribute("successMessage", msg);
        return "redirect:/admin/users";
    }

    @GetMapping("/requests")
    public String manageRequests(Model model) {
        List<BloodRequest> requests = bloodRequestService.getAllRequests();
        model.addAttribute("requests", requests);
        return "admin/manage-requests";
    }

    @PostMapping("/requests/{id}/cancel")
    public String cancelRequestByAdmin(@PathVariable("id") Long id,
                                       RedirectAttributes redirectAttributes) {
        User admin = userService.getUsersByRole(Role.ADMIN).get(0);
        bloodRequestService.cancelRequest(id, admin);
        redirectAttributes.addFlashAttribute("successMessage", "Request #" + id + " has been cancelled by administrator.");
        return "redirect:/admin/requests";
    }

    @GetMapping("/blood-banks")
    public String manageBloodBanks(Model model) {
        List<BloodBank> banks = bloodBankService.getAllBanks();
        model.addAttribute("bloodBanks", banks);
        return "admin/manage-blood-banks";
    }

    @PostMapping("/blood-banks/{id}/verify")
    public String verifyBloodBank(@PathVariable("id") Long id,
                                  @RequestParam("verify") boolean verify,
                                  RedirectAttributes redirectAttributes) {
        bloodBankService.verifyBank(id, verify);
        redirectAttributes.addFlashAttribute("successMessage", "Blood Bank verification status updated to " + verify + ".");
        return "redirect:/admin/blood-banks";
    }

    @GetMapping("/verifications")
    public String pendingVerifications(Model model) {
        List<User> pendingUsers = userService.getPendingVerifications();
        model.addAttribute("pendingUsers", pendingUsers);
        return "admin/verifications";
    }

    @PostMapping("/users/{id}/verify")
    public String verifyUser(@PathVariable("id") Long id,
                             @RequestParam("verify") boolean verify,
                             RedirectAttributes redirectAttributes) {
        userService.verifyUser(id, verify);
        redirectAttributes.addFlashAttribute("successMessage", "User verification status updated to " + verify + ".");
        return "redirect:/admin/verifications";
    }

    @GetMapping("/reports/csv")
    public void exportCsv(HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment; filename=\"blood_requests_report.csv\"");
        String csvData = bloodRequestService.exportRequestsToCsv();
        response.getWriter().write(csvData);
    }
}
