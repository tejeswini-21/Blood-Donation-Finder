package com.bloodfinder.controller;

import com.bloodfinder.dto.BloodRequestDto;
import com.bloodfinder.dto.StockUpdateDto;
import com.bloodfinder.entity.BloodBank;
import com.bloodfinder.entity.BloodRequest;
import com.bloodfinder.entity.BloodStock;
import com.bloodfinder.entity.User;
import com.bloodfinder.enums.BloodGroup;
import com.bloodfinder.enums.UrgencyLevel;
import com.bloodfinder.security.CustomUserDetails;
import com.bloodfinder.service.BloodBankService;
import com.bloodfinder.service.BloodRequestService;
import com.bloodfinder.service.NotificationService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/hospital")
public class HospitalController {

    private final BloodBankService bloodBankService;
    private final BloodRequestService bloodRequestService;
    private final NotificationService notificationService;

    public HospitalController(BloodBankService bloodBankService,
                              BloodRequestService bloodRequestService,
                              NotificationService notificationService) {
        this.bloodBankService = bloodBankService;
        this.bloodRequestService = bloodRequestService;
        this.notificationService = notificationService;
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        User user = userDetails.getUser();
        BloodBank bank = bloodBankService.getBankByHospitalUser(user);
        List<BloodStock> stocks = bloodBankService.getStockForBank(bank);
        List<BloodStock> lowStocks = bloodBankService.getLowStockAlerts(bank.getId());
        List<BloodRequest> myRequests = bloodRequestService.getRequestsByRequester(user);

        long totalUnits = stocks.stream().mapToLong(s -> s.getUnitsAvailable() != null ? s.getUnitsAvailable() : 0).sum();

        model.addAttribute("bank", bank);
        model.addAttribute("stocks", stocks);
        model.addAttribute("lowStocks", lowStocks);
        model.addAttribute("totalUnits", totalUnits);
        model.addAttribute("recentRequests", myRequests.stream().limit(5).toList());
        model.addAttribute("bloodGroups", BloodGroup.values());
        model.addAttribute("unreadNotifs", notificationService.getUnreadCount(user));

        return "hospital/dashboard";
    }

    @GetMapping("/stock")
    public String stockOverview(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        User user = userDetails.getUser();
        BloodBank bank = bloodBankService.getBankByHospitalUser(user);
        List<BloodStock> stocks = bloodBankService.getStockForBank(bank);
        List<BloodStock> lowStocks = bloodBankService.getLowStockAlerts(bank.getId());

        model.addAttribute("bank", bank);
        model.addAttribute("stocks", stocks);
        model.addAttribute("lowStocks", lowStocks);
        model.addAttribute("bloodGroups", BloodGroup.values());
        return "hospital/manage-stock";
    }

    @PostMapping("/stock/update")
    public String updateStock(@AuthenticationPrincipal CustomUserDetails userDetails,
                              @Valid @ModelAttribute("stockDto") StockUpdateDto stockDto,
                              BindingResult result,
                              RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Validation error: Stock cannot be negative.");
            return "redirect:/hospital/stock";
        }

        try {
            BloodBank bank = bloodBankService.getBankByHospitalUser(userDetails.getUser());
            bloodBankService.updateStock(bank.getId(), stockDto.getBloodGroup(), stockDto.getUnits());
            redirectAttributes.addFlashAttribute("successMessage",
                "Stock for " + stockDto.getBloodGroup().getLabel() + " updated to " + stockDto.getUnits() + " units.");
        } catch (IllegalArgumentException ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }
        return "redirect:/hospital/stock";
    }

    @GetMapping("/raise-request")
    public String showRaiseRequestForm(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        if (!model.containsAttribute("requestDto")) {
            BloodRequestDto dto = new BloodRequestDto();
            User user = userDetails.getUser();
            BloodBank bank = bloodBankService.getBankByHospitalUser(user);
            dto.setHospitalName(bank.getName());
            dto.setCity(bank.getCity());
            dto.setArea(bank.getArea());
            dto.setContactNumber(bank.getPhone());
            model.addAttribute("requestDto", dto);
        }
        model.addAttribute("bloodGroups", BloodGroup.values());
        model.addAttribute("urgencyLevels", UrgencyLevel.values());
        return "hospital/raise-request";
    }

    @PostMapping("/raise-request")
    public String processRaiseRequest(@AuthenticationPrincipal CustomUserDetails userDetails,
                                      @Valid @ModelAttribute("requestDto") BloodRequestDto requestDto,
                                      BindingResult bindingResult,
                                      RedirectAttributes redirectAttributes,
                                      Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("bloodGroups", BloodGroup.values());
            model.addAttribute("urgencyLevels", UrgencyLevel.values());
            return "hospital/raise-request";
        }

        try {
            User user = userDetails.getUser();
            BloodRequest saved = bloodRequestService.createRequest(user, requestDto);
            redirectAttributes.addFlashAttribute("successMessage", "Hospital blood request #" + saved.getId() + " raised successfully!");
            return "redirect:/hospital/requests";
        } catch (Exception ex) {
            model.addAttribute("bloodGroups", BloodGroup.values());
            model.addAttribute("urgencyLevels", UrgencyLevel.values());
            model.addAttribute("errorMessage", ex.getMessage());
            return "hospital/raise-request";
        }
    }

    @GetMapping("/requests")
    public String hospitalRequests(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        User user = userDetails.getUser();
        List<BloodRequest> myRequests = bloodRequestService.getRequestsByRequester(user);
        model.addAttribute("myRequests", myRequests);
        return "hospital/request-history";
    }
}
