package com.bloodfinder.controller;

import com.bloodfinder.entity.User;
import com.bloodfinder.security.CustomUserDetails;
import com.bloodfinder.service.NotificationService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/notifications")
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @GetMapping
    public String viewNotifications(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        User user = userDetails.getUser();
        model.addAttribute("notifications", notificationService.getUserNotifications(user));
        return "notifications/list";
    }

    @PostMapping("/{id}/mark-read")
    public String markAsRead(@PathVariable("id") Long id,
                             @AuthenticationPrincipal CustomUserDetails userDetails,
                             @RequestHeader(value = "Referer", required = false) String referer) {
        notificationService.markAsRead(id, userDetails.getUser());
        return "redirect:" + (referer != null ? referer : "/notifications");
    }

    @PostMapping("/mark-all-read")
    public String markAllAsRead(@AuthenticationPrincipal CustomUserDetails userDetails,
                                @RequestHeader(value = "Referer", required = false) String referer) {
        notificationService.markAllAsRead(userDetails.getUser());
        return "redirect:" + (referer != null ? referer : "/notifications");
    }
}
