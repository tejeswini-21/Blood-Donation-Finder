package com.bloodfinder.controller;

import com.bloodfinder.dto.ProfileUpdateDto;
import com.bloodfinder.entity.BloodRequest;
import com.bloodfinder.entity.DonationRecord;
import com.bloodfinder.entity.Donor;
import com.bloodfinder.entity.User;
import com.bloodfinder.exception.DonorNotEligibleException;
import com.bloodfinder.security.CustomUserDetails;
import com.bloodfinder.service.BloodRequestService;
import com.bloodfinder.service.DonationRecordService;
import com.bloodfinder.service.DonorService;
import com.bloodfinder.service.NotificationService;
import com.bloodfinder.service.UserService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/donor")
public class DonorController {

    private final DonorService donorService;
    private final BloodRequestService bloodRequestService;
    private final DonationRecordService donationRecordService;
    private final NotificationService notificationService;
    private final UserService userService;

    public DonorController(DonorService donorService,
                           BloodRequestService bloodRequestService,
                           DonationRecordService donationRecordService,
                           NotificationService notificationService,
                           UserService userService) {
        this.donorService = donorService;
        this.bloodRequestService = bloodRequestService;
        this.donationRecordService = donationRecordService;
        this.notificationService = notificationService;
        this.userService = userService;
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        User user = userDetails.getUser();
        Donor donor = donorService.getDonorByUser(user);

        boolean eligible = donorService.isEligible(donor);
        LocalDate nextEligibleDate = donorService.calculateNextEligibilityDate(donor);
        long daysUntilEligible = donorService.getDaysUntilEligible(donor);

        List<BloodRequest> incomingRequests = bloodRequestService.getIncomingRequestsForDonor(donor);
        List<DonationRecord> history = donationRecordService.getHistoryForDonor(donor);

        model.addAttribute("donor", donor);
        model.addAttribute("eligible", eligible);
        model.addAttribute("nextEligibleDate", nextEligibleDate);
        model.addAttribute("daysUntilEligible", daysUntilEligible);
        model.addAttribute("incomingRequests", incomingRequests);
        model.addAttribute("history", history);
        model.addAttribute("unreadNotifs", notificationService.getUnreadCount(user));

        return "donor/dashboard";
    }

    @GetMapping("/profile")
    public String profile(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        User user = userService.getByEmail(userDetails.getUsername());
        Donor donor = donorService.getDonorByUser(user);
        model.addAttribute("user", user);
        model.addAttribute("donor", donor);
        return "donor/profile";
    }

    @GetMapping("/edit-profile")
    public String showEditProfileForm(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        User user = userService.getByEmail(userDetails.getUsername());
        Donor donor = donorService.getDonorByUser(user);

        ProfileUpdateDto dto = new ProfileUpdateDto();
        dto.setName(user.getName());
        dto.setPhone(user.getPhone());
        dto.setCity(user.getCity());
        dto.setArea(user.getArea());
        dto.setAge(donor.getAge());
        dto.setGender(donor.getGender());

        model.addAttribute("profileDto", dto);
        model.addAttribute("donor", donor);
        return "donor/edit-profile";
    }

    @PostMapping("/edit-profile")
    public String updateProfile(@AuthenticationPrincipal CustomUserDetails userDetails,
                                @Valid @ModelAttribute("profileDto") ProfileUpdateDto dto,
                                BindingResult result,
                                RedirectAttributes redirectAttributes,
                                Model model) {
        if (result.hasErrors()) {
            return "donor/edit-profile";
        }

        User user = userDetails.getUser();
        userService.updateProfile(user.getId(), dto);
        redirectAttributes.addFlashAttribute("successMessage", "Profile updated successfully.");
        return "redirect:/donor/profile";
    }

    @PostMapping("/toggle-availability")
    public String toggleAvailability(@AuthenticationPrincipal CustomUserDetails userDetails,
                                     RedirectAttributes redirectAttributes) {
        Donor donor = donorService.getDonorByUser(userDetails.getUser());
        donorService.toggleAvailability(donor.getId());
        String status = !donor.isAvailable() ? "AVAILABLE" : "UNAVAILABLE";
        redirectAttributes.addFlashAttribute("successMessage", "Your availability has been changed to " + status + ".");
        return "redirect:/donor/dashboard";
    }

    @GetMapping("/requests")
    public String incomingRequests(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        Donor donor = donorService.getDonorByUser(userDetails.getUser());
        List<BloodRequest> requests = bloodRequestService.getIncomingRequestsForDonor(donor);
        model.addAttribute("donor", donor);
        model.addAttribute("requests", requests);
        model.addAttribute("isEligible", donorService.isEligible(donor));
        return "donor/incoming-requests";
    }

    @PostMapping("/requests/{id}/accept")
    public String acceptRequest(@PathVariable("id") Long requestId,
                                @AuthenticationPrincipal CustomUserDetails userDetails,
                                RedirectAttributes redirectAttributes) {
        Donor donor = donorService.getDonorByUser(userDetails.getUser());
        try {
            bloodRequestService.acceptRequest(requestId, donor);
            redirectAttributes.addFlashAttribute("successMessage", "You have successfully accepted the request! The recipient has been notified with your contact details.");
        } catch (DonorNotEligibleException ex) {
            redirectAttributes.addFlashAttribute("errorMessage", "Acceptance failed: " + ex.getMessage());
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error accepting request: " + ex.getMessage());
        }
        return "redirect:/donor/requests";
    }

    @PostMapping("/requests/{id}/reject")
    public String rejectRequest(@PathVariable("id") Long requestId,
                                @AuthenticationPrincipal CustomUserDetails userDetails,
                                RedirectAttributes redirectAttributes) {
        Donor donor = donorService.getDonorByUser(userDetails.getUser());
        bloodRequestService.rejectRequest(requestId, donor);
        redirectAttributes.addFlashAttribute("infoMessage", "You have declined this request.");
        return "redirect:/donor/requests";
    }

    @GetMapping("/history")
    public String donationHistory(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        Donor donor = donorService.getDonorByUser(userDetails.getUser());
        List<DonationRecord> history = donationRecordService.getHistoryForDonor(donor);
        model.addAttribute("donor", donor);
        model.addAttribute("history", history);
        return "donor/donation-history";
    }

    @GetMapping("/notifications")
    public String notifications(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        User user = userDetails.getUser();
        model.addAttribute("notifications", notificationService.getUserNotifications(user));
        return "donor/notifications";
    }
}
