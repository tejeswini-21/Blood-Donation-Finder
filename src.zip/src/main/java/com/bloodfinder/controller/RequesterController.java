package com.bloodfinder.controller;

import com.bloodfinder.dto.BloodRequestDto;
import com.bloodfinder.dto.DonorSearchDto;
import com.bloodfinder.entity.BloodRequest;
import com.bloodfinder.entity.Donor;
import com.bloodfinder.entity.User;
import com.bloodfinder.enums.BloodGroup;
import com.bloodfinder.enums.RequestStatus;
import com.bloodfinder.enums.UrgencyLevel;
import com.bloodfinder.exception.DuplicateRequestException;
import com.bloodfinder.exception.UnauthorizedActionException;
import com.bloodfinder.security.CustomUserDetails;
import com.bloodfinder.service.BloodRequestService;
import com.bloodfinder.service.DonorService;
import com.bloodfinder.service.NotificationService;
import com.bloodfinder.service.UserService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/requester")
public class RequesterController {

    private final BloodRequestService bloodRequestService;
    private final DonorService donorService;
    private final NotificationService notificationService;
    private final UserService userService;

    public RequesterController(BloodRequestService bloodRequestService,
                               DonorService donorService,
                               NotificationService notificationService,
                               UserService userService) {
        this.bloodRequestService = bloodRequestService;
        this.donorService = donorService;
        this.notificationService = notificationService;
        this.userService = userService;
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        User user = userDetails.getUser();
        List<BloodRequest> myRequests = bloodRequestService.getRequestsByRequester(user);

        long openCount = myRequests.stream().filter(r -> r.getStatus() == RequestStatus.OPEN).count();
        long acceptedCount = myRequests.stream().filter(r -> r.getStatus() == RequestStatus.ACCEPTED).count();
        long fulfilledCount = myRequests.stream().filter(r -> r.getStatus() == RequestStatus.FULFILLED).count();

        model.addAttribute("user", user);
        model.addAttribute("myRequests", myRequests);
        model.addAttribute("totalRequests", myRequests.size());
        model.addAttribute("openCount", openCount);
        model.addAttribute("acceptedCount", acceptedCount);
        model.addAttribute("fulfilledCount", fulfilledCount);
        model.addAttribute("unreadNotifs", notificationService.getUnreadCount(user));

        return "requester/dashboard";
    }

    @GetMapping("/create-request")
    public String showCreateRequestForm(@AuthenticationPrincipal CustomUserDetails userDetails,
                                        @RequestParam(value = "urgency", required = false) String urgencyParam,
                                        Model model) {
        if (!model.containsAttribute("requestDto")) {
            BloodRequestDto dto = new BloodRequestDto();
            User user = userDetails.getUser();
            dto.setCity(user.getCity());
            dto.setArea(user.getArea());
            dto.setContactNumber(user.getPhone());
            if ("EMERGENCY".equalsIgnoreCase(urgencyParam)) {
                dto.setUrgency(UrgencyLevel.EMERGENCY);
            }
            model.addAttribute("requestDto", dto);
        }
        model.addAttribute("bloodGroups", BloodGroup.values());
        model.addAttribute("urgencyLevels", UrgencyLevel.values());
        return "requester/create-request";
    }

    @PostMapping("/create-request")
    public String processCreateRequest(@AuthenticationPrincipal CustomUserDetails userDetails,
                                       @Valid @ModelAttribute("requestDto") BloodRequestDto requestDto,
                                       BindingResult bindingResult,
                                       RedirectAttributes redirectAttributes,
                                       Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("bloodGroups", BloodGroup.values());
            model.addAttribute("urgencyLevels", UrgencyLevel.values());
            return "requester/create-request";
        }

        try {
            User user = userDetails.getUser();
            BloodRequest saved = bloodRequestService.createRequest(user, requestDto);
            redirectAttributes.addFlashAttribute("successMessage",
                "Blood request #" + saved.getId() + " created successfully! Eligible donors in " + saved.getCity() + " have been notified.");
            return "redirect:/requester/requests/" + saved.getId();
        } catch (DuplicateRequestException ex) {
            model.addAttribute("bloodGroups", BloodGroup.values());
            model.addAttribute("urgencyLevels", UrgencyLevel.values());
            model.addAttribute("errorMessage", ex.getMessage());
            return "requester/create-request";
        }
    }

    @GetMapping("/requests")
    public String myRequests(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        User user = userDetails.getUser();
        List<BloodRequest> myRequests = bloodRequestService.getRequestsByRequester(user);
        model.addAttribute("myRequests", myRequests);
        return "requester/my-requests";
    }

    @GetMapping("/requests/{id}")
    public String requestDetails(@PathVariable("id") Long id,
                                 @AuthenticationPrincipal CustomUserDetails userDetails,
                                 Model model) {
        BloodRequest request = bloodRequestService.getRequestById(id);
        User currentUser = userDetails.getUser();
        boolean isOwner = request.getRequester().getId().equals(currentUser.getId());
        if (!isOwner) {
            throw new UnauthorizedActionException("You can only view your own blood requests.");
        }

        // Privacy rule: Donor contact info is ONLY visible when request is ACCEPTED or FULFILLED
        boolean showDonorContact = (request.getStatus() == RequestStatus.ACCEPTED || request.getStatus() == RequestStatus.FULFILLED)
                                   && request.getAcceptedBy() != null;

        model.addAttribute("req", request);
        model.addAttribute("showDonorContact", showDonorContact);
        model.addAttribute("isOwner", isOwner);
        return "requester/request-details";
    }

    @PostMapping("/requests/{id}/fulfill")
    public String confirmFulfillment(@PathVariable("id") Long id,
                                     @RequestParam(value = "remarks", required = false) String remarks,
                                     @AuthenticationPrincipal CustomUserDetails userDetails,
                                     RedirectAttributes redirectAttributes) {
        try {
            bloodRequestService.fulfillRequest(id, userDetails.getUser(), remarks);
            redirectAttributes.addFlashAttribute("successMessage", "Blood donation marked as FULFILLED! Thank you for updating the system.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", "Could not confirm fulfillment: " + ex.getMessage());
        }
        return "redirect:/requester/requests/" + id;
    }

    @PostMapping("/requests/{id}/cancel")
    public String cancelRequest(@PathVariable("id") Long id,
                                @AuthenticationPrincipal CustomUserDetails userDetails,
                                RedirectAttributes redirectAttributes) {
        try {
            bloodRequestService.cancelRequest(id, userDetails.getUser());
            redirectAttributes.addFlashAttribute("infoMessage", "Request #" + id + " has been cancelled.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", "Could not cancel request: " + ex.getMessage());
        }
        return "redirect:/requester/requests";
    }

    @GetMapping("/matching-donors")
    public String matchingDonors(@ModelAttribute("searchDto") DonorSearchDto searchDto,
                                 @AuthenticationPrincipal CustomUserDetails userDetails,
                                 Model model) {
        model.addAttribute("bloodGroups", BloodGroup.values());

        if (searchDto.getBloodGroup() != null) {
            List<Donor> results = donorService.findEligibleDonors(
                searchDto.getBloodGroup(), searchDto.getCity(), searchDto.getArea()
            );
            model.addAttribute("donors", results);
            model.addAttribute("searchPerformed", true);
        } else {
            User user = userDetails.getUser();
            model.addAttribute("donors", donorService.getAllDonors().stream().filter(donorService::isEligible).toList());
            model.addAttribute("searchPerformed", false);
        }

        return "requester/matching-donors";
    }

    @GetMapping("/notifications")
    public String notifications(@AuthenticationPrincipal CustomUserDetails userDetails, Model model) {
        User user = userDetails.getUser();
        model.addAttribute("notifications", notificationService.getUserNotifications(user));
        return "requester/notifications";
    }
}
