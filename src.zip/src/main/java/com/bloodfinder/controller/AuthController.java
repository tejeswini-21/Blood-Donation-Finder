package com.bloodfinder.controller;

import com.bloodfinder.dto.DonorRegistrationDto;
import com.bloodfinder.dto.HospitalRegistrationDto;
import com.bloodfinder.dto.RequesterRegistrationDto;
import com.bloodfinder.enums.BloodGroup;
import com.bloodfinder.service.UserService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String login(@RequestParam(value = "error", required = false) String error,
                        @RequestParam(value = "logout", required = false) String logout,
                        Model model) {
        if (error != null) {
            model.addAttribute("errorMessage", "Sign-in failed. Check the email and password, or confirm the account is verified and not blocked.");
        }
        if (logout != null) {
            model.addAttribute("successMessage", "You have been logged out successfully.");
        }
        return "auth/login";
    }

    @GetMapping("/register")
    public String registerLanding() {
        return "auth/register-portal";
    }

    @GetMapping("/register/donor")
    public String showDonorRegistrationForm(Model model) {
        if (!model.containsAttribute("donorDto")) {
            model.addAttribute("donorDto", new DonorRegistrationDto());
        }
        model.addAttribute("bloodGroups", BloodGroup.values());
        return "auth/register-donor";
    }

    @PostMapping("/register/donor")
    public String processDonorRegistration(@Valid @ModelAttribute("donorDto") DonorRegistrationDto donorDto,
                                           BindingResult bindingResult,
                                           RedirectAttributes redirectAttributes,
                                           Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("bloodGroups", BloodGroup.values());
            return "auth/register-donor";
        }

        try {
            userService.registerDonor(donorDto);
            redirectAttributes.addFlashAttribute("successMessage", "Donor account registered successfully! You may now sign in.");
            return "redirect:/login";
        } catch (IllegalArgumentException ex) {
            model.addAttribute("bloodGroups", BloodGroup.values());
            model.addAttribute("errorMessage", ex.getMessage());
            return "auth/register-donor";
        }
    }

    @GetMapping("/register/requester")
    public String showRequesterRegistrationForm(Model model) {
        if (!model.containsAttribute("requesterDto")) {
            model.addAttribute("requesterDto", new RequesterRegistrationDto());
        }
        return "auth/register-requester";
    }

    @PostMapping("/register/requester")
    public String processRequesterRegistration(@Valid @ModelAttribute("requesterDto") RequesterRegistrationDto requesterDto,
                                               BindingResult bindingResult,
                                               RedirectAttributes redirectAttributes,
                                               Model model) {
        if (bindingResult.hasErrors()) {
            return "auth/register-requester";
        }

        try {
            userService.registerRequester(requesterDto);
            redirectAttributes.addFlashAttribute("successMessage", "Recipient account registered successfully! You may now sign in.");
            return "redirect:/login";
        } catch (IllegalArgumentException ex) {
            model.addAttribute("errorMessage", ex.getMessage());
            return "auth/register-requester";
        }
    }

    @GetMapping("/register/hospital")
    public String showHospitalRegistrationForm(Model model) {
        if (!model.containsAttribute("hospitalDto")) {
            model.addAttribute("hospitalDto", new HospitalRegistrationDto());
        }
        return "auth/register-hospital";
    }

    @PostMapping("/register/hospital")
    public String processHospitalRegistration(@Valid @ModelAttribute("hospitalDto") HospitalRegistrationDto hospitalDto,
                                              BindingResult bindingResult,
                                              RedirectAttributes redirectAttributes,
                                              Model model) {
        if (bindingResult.hasErrors()) {
            return "auth/register-hospital";
        }

        try {
            userService.registerHospital(hospitalDto);
            redirectAttributes.addFlashAttribute("successMessage", "Hospital/Blood Bank registered! Your account is submitted for Admin verification.");
            return "redirect:/login";
        } catch (IllegalArgumentException ex) {
            model.addAttribute("errorMessage", ex.getMessage());
            return "auth/register-hospital";
        }
    }
}
