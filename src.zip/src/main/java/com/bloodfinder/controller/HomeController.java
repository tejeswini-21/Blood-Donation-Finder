package com.bloodfinder.controller;

import com.bloodfinder.dto.DonorSearchDto;
import com.bloodfinder.entity.BloodBank;
import com.bloodfinder.entity.BloodRequest;
import com.bloodfinder.entity.BloodStock;
import com.bloodfinder.entity.Donor;
import com.bloodfinder.enums.BloodGroup;
import com.bloodfinder.service.BloodBankService;
import com.bloodfinder.service.BloodRequestService;
import com.bloodfinder.service.DonationRecordService;
import com.bloodfinder.service.DonorService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class HomeController {

    private final DonorService donorService;
    private final BloodRequestService bloodRequestService;
    private final BloodBankService bloodBankService;
    private final DonationRecordService donationRecordService;

    public HomeController(DonorService donorService,
                          BloodRequestService bloodRequestService,
                          BloodBankService bloodBankService,
                          DonationRecordService donationRecordService) {
        this.donorService = donorService;
        this.bloodRequestService = bloodRequestService;
        this.bloodBankService = bloodBankService;
        this.donationRecordService = donationRecordService;
    }

    @GetMapping({"/", "/home"})
    public String home(Model model) {
        // Live platform statistics (real database values)
        model.addAttribute("totalDonors", donorService.getTotalDonorCount());
        model.addAttribute("availableDonors", donorService.getAvailableDonorCount());
        model.addAttribute("totalRequests", bloodRequestService.getTotalRequestCount());
        model.addAttribute("fulfilledRequests", bloodRequestService.getFulfilledRequestCount());
        model.addAttribute("emergencyRequestsCount", bloodRequestService.getEmergencyRequestCount());
        model.addAttribute("totalBanks", bloodBankService.getTotalBloodBanks());
        model.addAttribute("totalUnitsStock", bloodBankService.getTotalAvailableUnits());

        // Recent emergency & urgent open requests for the homepage ticker/cards
        List<BloodRequest> openRequests = bloodRequestService.getOpenRequests();
        model.addAttribute("recentRequests", openRequests.stream().limit(6).toList());

        model.addAttribute("bloodGroups", BloodGroup.values());
        return "index";
    }

    @GetMapping("/about")
    public String about(Model model) {
        model.addAttribute("bloodGroups", BloodGroup.values());
        return "about";
    }

    @GetMapping("/find-donors")
    public String findDonors(@ModelAttribute("searchDto") DonorSearchDto searchDto,
                             Model model) {
        model.addAttribute("bloodGroups", BloodGroup.values());

        if (searchDto.getBloodGroup() != null) {
            List<Donor> results = donorService.findEligibleDonors(
                searchDto.getBloodGroup(), searchDto.getCity(), searchDto.getArea()
            );
            model.addAttribute("donors", results);
            model.addAttribute("searchPerformed", true);
        } else {
            // Default show all active eligible donors
            List<Donor> all = donorService.getAllDonors().stream()
                .filter(donorService::isEligible)
                .limit(10)
                .toList();
            model.addAttribute("donors", all);
            model.addAttribute("searchPerformed", false);
        }

        return "find-donors";
    }

    @GetMapping("/blood-banks")
    public String bloodBanks(@RequestParam(value = "city", required = false) String city,
                             @RequestParam(value = "bloodGroup", required = false) BloodGroup bloodGroup,
                             Model model) {
        model.addAttribute("bloodGroups", BloodGroup.values());
        model.addAttribute("selectedCity", city);
        model.addAttribute("selectedBloodGroup", bloodGroup);

        List<BloodBank> banks = bloodBankService.getBanksByCity(city);
        model.addAttribute("bloodBanks", banks);

        List<BloodStock> availableStocks = bloodBankService.searchAvailableStock(city, bloodGroup);
        model.addAttribute("availableStocks", availableStocks);

        return "blood-banks";
    }

    @GetMapping("/access-denied")
    public String accessDenied() {
        return "error/403";
    }
}
