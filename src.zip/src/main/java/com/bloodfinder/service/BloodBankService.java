package com.bloodfinder.service;

import com.bloodfinder.entity.BloodBank;
import com.bloodfinder.entity.BloodStock;
import com.bloodfinder.entity.User;
import com.bloodfinder.enums.BloodGroup;
import java.util.List;
import java.util.Optional;

public interface BloodBankService {
    BloodBank getBankById(Long id);
    Optional<BloodBank> findBankByHospitalUser(User user);
    BloodBank getBankByHospitalUser(User user);
    List<BloodBank> getAllBanks();
    List<BloodBank> getVerifiedBanks();
    List<BloodBank> getBanksByCity(String city);
    void verifyBank(Long bankId, boolean verify);
    BloodStock updateStock(Long bankId, BloodGroup bloodGroup, int units);
    List<BloodStock> getStockForBank(BloodBank bank);
    List<BloodStock> searchAvailableStock(String city, BloodGroup bloodGroup);
    List<BloodStock> getLowStockAlerts(Long bankId);
    List<BloodStock> getAllLowStockAlerts();
    long getTotalBloodBanks();
    long getTotalAvailableUnits();
}
