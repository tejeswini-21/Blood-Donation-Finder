package com.bloodfinder.service;

import com.bloodfinder.dto.ProfileUpdateDto;
import com.bloodfinder.entity.Donor;
import com.bloodfinder.entity.User;
import com.bloodfinder.enums.BloodGroup;
import java.time.LocalDate;
import java.util.List;

public interface DonorService {
    Donor getDonorByUser(User user);
    Donor getDonorByUserId(Long userId);
    Donor getDonorById(Long id);
    boolean isEligible(Donor donor);
    LocalDate calculateNextEligibilityDate(Donor donor);
    long getDaysUntilEligible(Donor donor);
    void toggleAvailability(Long donorId);
    List<Donor> findEligibleDonors(BloodGroup requiredGroup, String city, String area);
    List<Donor> getAllDonors();
    Donor updateDonorProfile(Long donorId, ProfileUpdateDto dto);
    long getTotalDonorCount();
    long getAvailableDonorCount();
}
