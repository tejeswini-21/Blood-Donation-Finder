package com.bloodfinder.service;

import com.bloodfinder.entity.Notification;
import com.bloodfinder.entity.User;
import java.util.List;

public interface NotificationService {
    Notification sendNotification(User user, String message, String linkUrl);
    Notification sendNotification(User user, String message);
    List<Notification> getUserNotifications(User user);
    long getUnreadCount(User user);
    void markAsRead(Long notificationId, User user);
    void markAllAsRead(User user);
    void sendEmailSafe(String toEmail, String subject, String body);
}
