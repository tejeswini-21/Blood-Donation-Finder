package com.bloodfinder.service;

import com.bloodfinder.entity.DonationRecord;
import com.bloodfinder.entity.Donor;
import java.util.List;

public interface DonationRecordService {
    List<DonationRecord> getHistoryForDonor(Donor donor);
    DonationRecord saveRecord(DonationRecord record);
    long getTotalDonationsCount();
}
