package com.bloodfinder.service;

import com.bloodfinder.dto.AdminDashboardDto;

public interface AdminService {
    AdminDashboardDto getDashboardStats();
}
