package com.bloodfinder.service;

import com.bloodfinder.dto.BloodRequestDto;
import com.bloodfinder.entity.BloodRequest;
import com.bloodfinder.entity.Donor;
import com.bloodfinder.entity.User;
import java.util.List;

public interface BloodRequestService {
    BloodRequest createRequest(User requester, BloodRequestDto dto);
    BloodRequest getRequestById(Long id);
    List<BloodRequest> getRequestsByRequester(User requester);
    List<BloodRequest> getIncomingRequestsForDonor(Donor donor);
    BloodRequest acceptRequest(Long requestId, Donor donor);
    void rejectRequest(Long requestId, Donor donor);
    BloodRequest fulfillRequest(Long requestId, User actor, String remarks);
    BloodRequest cancelRequest(Long requestId, User actor);
    int expirePastRequests();
    List<BloodRequest> getAllRequests();
    List<BloodRequest> getOpenRequests();
    String exportRequestsToCsv();
    long getTotalRequestCount();
    long getEmergencyRequestCount();
    long getFulfilledRequestCount();
}
