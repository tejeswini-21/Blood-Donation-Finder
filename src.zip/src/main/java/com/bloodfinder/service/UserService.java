package com.bloodfinder.service;

import com.bloodfinder.dto.DonorRegistrationDto;
import com.bloodfinder.dto.HospitalRegistrationDto;
import com.bloodfinder.dto.ProfileUpdateDto;
import com.bloodfinder.dto.RequesterRegistrationDto;
import com.bloodfinder.entity.User;
import com.bloodfinder.enums.Role;
import java.util.List;
import java.util.Optional;

public interface UserService {
    User registerDonor(DonorRegistrationDto dto);
    User registerRequester(RequesterRegistrationDto dto);
    User registerHospital(HospitalRegistrationDto dto);
    Optional<User> findById(Long id);
    Optional<User> findByEmail(String email);
    User getByEmail(String email);
    User updateProfile(Long userId, ProfileUpdateDto dto);
    void verifyUser(Long userId, boolean verify);
    void toggleUserStatus(Long userId, boolean enabled);
    List<User> getAllUsers();
    List<User> getUsersByRole(Role role);
    List<User> getPendingVerifications();
    long getTotalUserCount();
}
