package com.bloodfinder.service.impl;

import com.bloodfinder.dto.ProfileUpdateDto;
import com.bloodfinder.entity.Donor;
import com.bloodfinder.entity.User;
import com.bloodfinder.enums.BloodGroup;
import com.bloodfinder.exception.ResourceNotFoundException;
import com.bloodfinder.repository.DonorRepository;
import com.bloodfinder.service.DonorService;
import com.bloodfinder.util.BloodCompatibilityUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class DonorServiceImpl implements DonorService {

    private static final Logger log = LoggerFactory.getLogger(DonorServiceImpl.class);

    private final DonorRepository donorRepository;

    @Value("${app.donor.eligibility-days:90}")
    private int eligibilityDays;

    public DonorServiceImpl(DonorRepository donorRepository) {
        this.donorRepository = donorRepository;
    }

    public void setEligibilityDays(int eligibilityDays) {
        this.eligibilityDays = eligibilityDays;
    }

    public int getEligibilityDays() {
        return eligibilityDays;
    }

    @Override
    @Transactional(readOnly = true)
    public Donor getDonorByUser(User user) {
        return donorRepository.findByUser(user)
            .orElseThrow(() -> new ResourceNotFoundException("Donor profile not found for user: " + user.getEmail()));
    }

    @Override
    @Transactional(readOnly = true)
    public Donor getDonorByUserId(Long userId) {
        return donorRepository.findByUserId(userId)
            .orElseThrow(() -> new ResourceNotFoundException("Donor profile not found for user id: " + userId));
    }

    @Override
    @Transactional(readOnly = true)
    public Donor getDonorById(Long id) {
        return donorRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Donor not found with id: " + id));
    }

    @Override
    public boolean isEligible(Donor donor) {
        if (donor == null || donor.getUser() == null) {
            return false;
        }

        User user = donor.getUser();
        if (!user.isEnabled() || !user.isVerified() || !donor.isAvailable()) {
            return false;
        }

        if (donor.getLastDonationDate() == null) {
            return true;
        }

        LocalDate nextDate = donor.getLastDonationDate().plusDays(eligibilityDays);
        return !nextDate.isAfter(LocalDate.now());
    }

    @Override
    public LocalDate calculateNextEligibilityDate(Donor donor) {
        if (donor == null || donor.getLastDonationDate() == null) {
            return LocalDate.now();
        }
        return donor.getLastDonationDate().plusDays(eligibilityDays);
    }

    @Override
    public long getDaysUntilEligible(Donor donor) {
        if (donor == null || donor.getLastDonationDate() == null) {
            return 0;
        }
        LocalDate nextDate = calculateNextEligibilityDate(donor);
        long days = ChronoUnit.DAYS.between(LocalDate.now(), nextDate);
        return Math.max(0, days);
    }

    @Override
    @Transactional
    public void toggleAvailability(Long donorId) {
        Donor donor = getDonorById(donorId);
        donor.setAvailable(!donor.isAvailable());
        donorRepository.save(donor);
        log.info("Toggled availability for donor id {} to {}", donorId, donor.isAvailable());
    }

    @Override
    @Transactional(readOnly = true)
    public List<Donor> findEligibleDonors(BloodGroup requiredGroup, String city, String area) {
        Set<BloodGroup> compatibleGroups = BloodCompatibilityUtil.getCompatibleDonors(requiredGroup);
        List<Donor> allMatching = donorRepository.findByBloodGroupIn(compatibleGroups);

        return allMatching.stream()
            .filter(this::isEligible)
            .filter(d -> city == null || city.isBlank() || d.getUser().getCity().equalsIgnoreCase(city.trim()))
            .sorted((d1, d2) -> {
                // Prioritize same area if area is specified
                if (area != null && !area.isBlank()) {
                    boolean d1AreaMatch = d1.getUser().getArea() != null && d1.getUser().getArea().equalsIgnoreCase(area.trim());
                    boolean d2AreaMatch = d2.getUser().getArea() != null && d2.getUser().getArea().equalsIgnoreCase(area.trim());
                    if (d1AreaMatch != d2AreaMatch) {
                        return d1AreaMatch ? -1 : 1;
                    }
                }
                // Then sort by total donations desc, then name
                int donationCompare = Integer.compare(d2.getTotalDonations(), d1.getTotalDonations());
                if (donationCompare != 0) return donationCompare;
                return d1.getUser().getName().compareToIgnoreCase(d2.getUser().getName());
            })
            .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<Donor> getAllDonors() {
        return donorRepository.findAll();
    }

    @Override
    @Transactional
    public Donor updateDonorProfile(Long donorId, ProfileUpdateDto dto) {
        Donor donor = getDonorById(donorId);
        if (dto.getAge() != null) donor.setAge(dto.getAge());
        if (dto.getGender() != null) donor.setGender(dto.getGender());
        return donorRepository.save(donor);
    }

    @Override
    @Transactional(readOnly = true)
    public long getTotalDonorCount() {
        return donorRepository.count();
    }

    @Override
    @Transactional(readOnly = true)
    public long getAvailableDonorCount() {
        return donorRepository.countByAvailableTrue();
    }
}
