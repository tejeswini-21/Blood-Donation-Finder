package com.bloodfinder.service.impl;

import com.bloodfinder.dto.AdminDashboardDto;
import com.bloodfinder.entity.BloodRequest;
import com.bloodfinder.entity.Donor;
import com.bloodfinder.enums.BloodGroup;
import com.bloodfinder.enums.RequestStatus;
import com.bloodfinder.enums.Role;
import com.bloodfinder.enums.UrgencyLevel;
import com.bloodfinder.repository.*;
import com.bloodfinder.service.AdminService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AdminServiceImpl implements AdminService {

    private final UserRepository userRepository;
    private final DonorRepository donorRepository;
    private final BloodRequestRepository bloodRequestRepository;
    private final BloodBankRepository bloodBankRepository;
    private final BloodStockRepository bloodStockRepository;

    public AdminServiceImpl(UserRepository userRepository,
                            DonorRepository donorRepository,
                            BloodRequestRepository bloodRequestRepository,
                            BloodBankRepository bloodBankRepository,
                            BloodStockRepository bloodStockRepository) {
        this.userRepository = userRepository;
        this.donorRepository = donorRepository;
        this.bloodRequestRepository = bloodRequestRepository;
        this.bloodBankRepository = bloodBankRepository;
        this.bloodStockRepository = bloodStockRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public AdminDashboardDto getDashboardStats() {
        AdminDashboardDto dto = new AdminDashboardDto();

        dto.setTotalUsers(userRepository.count());
        dto.setTotalDonors(donorRepository.count());
        dto.setTotalRequesters(userRepository.countByRole(Role.REQUESTER));
        dto.setTotalHospitals(userRepository.countByRole(Role.HOSPITAL));
        dto.setTotalRequests(bloodRequestRepository.count());
        dto.setEmergencyRequests(bloodRequestRepository.countByUrgency(UrgencyLevel.EMERGENCY));
        dto.setFulfilledRequests(bloodRequestRepository.countByStatus(RequestStatus.FULFILLED));
        dto.setPendingVerifications(userRepository.countByVerifiedFalse());

        long totalUnits = bloodStockRepository.findAll().stream()
            .mapToLong(s -> s.getUnitsAvailable() != null ? s.getUnitsAvailable() : 0)
            .sum();
        dto.setTotalUnitsInStock(totalUnits);

        // Donors per blood group
        Map<String, Long> bgMap = new LinkedHashMap<>();
        for (BloodGroup bg : BloodGroup.values()) {
            bgMap.put(bg.getLabel(), donorRepository.countByBloodGroup(bg));
        }
        dto.setDonorsPerBloodGroup(bgMap);

        // Requests per city
        List<BloodRequest> allRequests = bloodRequestRepository.findAll();
        Map<String, Long> cityMap = allRequests.stream()
            .collect(Collectors.groupingBy(BloodRequest::getCity, Collectors.counting()));
        dto.setRequestsPerCity(cityMap);

        // Requests by status
        Map<String, Long> statusMap = new LinkedHashMap<>();
        for (RequestStatus st : RequestStatus.values()) {
            statusMap.put(st.name(), bloodRequestRepository.countByStatus(st));
        }
        dto.setRequestsByStatus(statusMap);

        return dto;
    }
}
