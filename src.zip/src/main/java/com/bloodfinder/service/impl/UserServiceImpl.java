package com.bloodfinder.service.impl;

import com.bloodfinder.dto.DonorRegistrationDto;
import com.bloodfinder.dto.HospitalRegistrationDto;
import com.bloodfinder.dto.ProfileUpdateDto;
import com.bloodfinder.dto.RequesterRegistrationDto;
import com.bloodfinder.entity.BloodBank;
import com.bloodfinder.entity.BloodStock;
import com.bloodfinder.entity.Donor;
import com.bloodfinder.entity.User;
import com.bloodfinder.enums.BloodGroup;
import com.bloodfinder.enums.Role;
import com.bloodfinder.exception.ResourceNotFoundException;
import com.bloodfinder.repository.BloodBankRepository;
import com.bloodfinder.repository.BloodStockRepository;
import com.bloodfinder.repository.DonorRepository;
import com.bloodfinder.repository.UserRepository;
import com.bloodfinder.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    private final UserRepository userRepository;
    private final DonorRepository donorRepository;
    private final BloodBankRepository bloodBankRepository;
    private final BloodStockRepository bloodStockRepository;
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository,
                           DonorRepository donorRepository,
                           BloodBankRepository bloodBankRepository,
                           BloodStockRepository bloodStockRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.donorRepository = donorRepository;
        this.bloodBankRepository = bloodBankRepository;
        this.bloodStockRepository = bloodStockRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public User registerDonor(DonorRegistrationDto dto) {
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("An account with email " + dto.getEmail() + " already exists.");
        }

        User user = new User(
            dto.getName(),
            dto.getEmail().toLowerCase().trim(),
            dto.getPhone().trim(),
            passwordEncoder.encode(dto.getPassword()),
            Role.DONOR,
            dto.getCity().trim(),
            dto.getArea() != null ? dto.getArea().trim() : null
        );
        user.setEnabled(true);
        user.setVerified(true); // Donors verified upon self-registration for demo
        User savedUser = userRepository.save(user);

        Donor donor = new Donor(
            savedUser,
            dto.getBloodGroup(),
            dto.getAge(),
            dto.getGender(),
            dto.getLastDonationDate(),
            true
        );
        donorRepository.save(donor);

        log.info("Registered new donor user: {} ({})", savedUser.getEmail(), dto.getBloodGroup());
        return savedUser;
    }

    @Override
    @Transactional
    public User registerRequester(RequesterRegistrationDto dto) {
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("An account with email " + dto.getEmail() + " already exists.");
        }

        User user = new User(
            dto.getName(),
            dto.getEmail().toLowerCase().trim(),
            dto.getPhone().trim(),
            passwordEncoder.encode(dto.getPassword()),
            Role.REQUESTER,
            dto.getCity().trim(),
            dto.getArea() != null ? dto.getArea().trim() : null
        );
        user.setEnabled(true);
        user.setVerified(true);
        User savedUser = userRepository.save(user);

        log.info("Registered new requester user: {}", savedUser.getEmail());
        return savedUser;
    }

    @Override
    @Transactional
    public User registerHospital(HospitalRegistrationDto dto) {
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("An account with email " + dto.getEmail() + " already exists.");
        }

        User user = new User(
            dto.getName(),
            dto.getEmail().toLowerCase().trim(),
            dto.getPhone().trim(),
            passwordEncoder.encode(dto.getPassword()),
            Role.HOSPITAL,
            dto.getCity().trim(),
            dto.getArea() != null ? dto.getArea().trim() : null
        );
        user.setEnabled(true);
        user.setVerified(false); // Hospitals require Admin verification
        User savedUser = userRepository.save(user);

        BloodBank bank = new BloodBank(
            dto.getName(),
            dto.getCity().trim(),
            dto.getArea() != null ? dto.getArea().trim() : null,
            dto.getPhone().trim(),
            dto.getAddress(),
            savedUser,
            false
        );
        BloodBank savedBank = bloodBankRepository.save(bank);

        // Initialize zero stock across all 8 blood groups
        for (BloodGroup bg : BloodGroup.values()) {
            BloodStock stock = new BloodStock(savedBank, bg, 0);
            bloodStockRepository.save(stock);
        }

        log.info("Registered new hospital/blood bank user (pending verification): {}", savedUser.getEmail());
        return savedUser;
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Override
    @Transactional(readOnly = true)
    public User getByEmail(String email) {
        return userRepository.findByEmail(email)
            .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }

    @Override
    @Transactional
    public User updateProfile(Long userId, ProfileUpdateDto dto) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        user.setName(dto.getName().trim());
        user.setPhone(dto.getPhone().trim());
        user.setCity(dto.getCity().trim());
        user.setArea(dto.getArea() != null ? dto.getArea().trim() : null);

        if (user.getRole() == Role.DONOR) {
            donorRepository.findByUser(user).ifPresent(d -> {
                if (dto.getAge() != null) d.setAge(dto.getAge());
                if (dto.getGender() != null) d.setGender(dto.getGender());
                donorRepository.save(d);
            });
        }

        log.info("Updated profile for user id: {}", userId);
        return userRepository.save(user);
    }

    @Override
    @Transactional
    public void verifyUser(Long userId, boolean verify) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
        user.setVerified(verify);
        userRepository.save(user);

        if (user.getRole() == Role.HOSPITAL) {
            bloodBankRepository.findByHospitalUser(user).ifPresent(bank -> {
                bank.setVerified(verify);
                bloodBankRepository.save(bank);
            });
        }
        log.info("Set verification status for user {} to {}", userId, verify);
    }

    @Override
    @Transactional
    public void toggleUserStatus(Long userId, boolean enabled) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
        user.setEnabled(enabled);
        userRepository.save(user);
        log.info("Set account enabled status for user {} to {}", userId, enabled);
    }

    @Override
    @Transactional(readOnly = true)
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<User> getUsersByRole(Role role) {
        return userRepository.findByRole(role);
    }

    @Override
    @Transactional(readOnly = true)
    public List<User> getPendingVerifications() {
        return userRepository.findByVerifiedFalse();
    }

    @Override
    @Transactional(readOnly = true)
    public long getTotalUserCount() {
        return userRepository.count();
    }
}
