package com.bloodfinder.service.impl;

import com.bloodfinder.dto.BloodRequestDto;
import com.bloodfinder.entity.*;
import com.bloodfinder.enums.*;
import com.bloodfinder.exception.*;
import com.bloodfinder.repository.*;
import com.bloodfinder.service.BloodRequestService;
import com.bloodfinder.service.DonorService;
import com.bloodfinder.service.NotificationService;
import com.bloodfinder.util.BloodCompatibilityUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class BloodRequestServiceImpl implements BloodRequestService {

    private static final Logger log = LoggerFactory.getLogger(BloodRequestServiceImpl.class);

    private final BloodRequestRepository bloodRequestRepository;
    private final DonationRecordRepository donationRecordRepository;
    private final RequestResponseRepository requestResponseRepository;
    private final DonorRepository donorRepository;
    private final DonorService donorService;
    private final NotificationService notificationService;

    public BloodRequestServiceImpl(BloodRequestRepository bloodRequestRepository,
                                   DonationRecordRepository donationRecordRepository,
                                   RequestResponseRepository requestResponseRepository,
                                   DonorRepository donorRepository,
                                   DonorService donorService,
                                   NotificationService notificationService) {
        this.bloodRequestRepository = bloodRequestRepository;
        this.donationRecordRepository = donationRecordRepository;
        this.requestResponseRepository = requestResponseRepository;
        this.donorRepository = donorRepository;
        this.donorService = donorService;
        this.notificationService = notificationService;
    }

    @Override
    @Transactional
    public BloodRequest createRequest(User requester, BloodRequestDto dto) {
        // Prevent duplicate OPEN requests for the same patient and blood group by the same requester
        boolean exists = bloodRequestRepository.existsByRequesterAndPatientNameIgnoreCaseAndBloodGroupAndStatus(
            requester, dto.getPatientName().trim(), dto.getBloodGroup(), RequestStatus.OPEN
        );
        if (exists) {
            throw new DuplicateRequestException(
                "An open blood request for patient '" + dto.getPatientName() + "' with blood group " +
                dto.getBloodGroup().getLabel() + " already exists."
            );
        }

        BloodRequest request = new BloodRequest(
            requester,
            dto.getPatientName().trim(),
            dto.getBloodGroup(),
            dto.getUnitsNeeded(),
            dto.getHospitalName().trim(),
            dto.getCity().trim(),
            dto.getArea() != null ? dto.getArea().trim() : null,
            dto.getUrgency(),
            dto.getRequiredBy(),
            dto.getContactNumber().trim(),
            dto.getNotes()
        );
        request.setStatus(RequestStatus.OPEN);
        BloodRequest savedRequest = bloodRequestRepository.save(request);

        // Notify matching donors in the area/city
        notifyMatchingDonors(savedRequest);

        log.info("Created blood request #{} for patient {} ({}) by user {}",
            savedRequest.getId(), savedRequest.getPatientName(), savedRequest.getBloodGroup(), requester.getEmail());
        return savedRequest;
    }

    private void notifyMatchingDonors(BloodRequest req) {
        try {
            List<Donor> matchingDonors = donorService.findEligibleDonors(req.getBloodGroup(), req.getCity(), req.getArea());
            String urgencyPrefix = req.getUrgency() == UrgencyLevel.EMERGENCY ? "🚨 EMERGENCY: " : "Notice: ";
            String msg = urgencyPrefix + req.getUnitsNeeded() + " unit(s) of " + req.getBloodGroup().getLabel() +
                " required for patient " + req.getPatientName() + " at " + req.getHospitalName() + ", " + req.getCity() + ".";

            for (Donor d : matchingDonors) {
                notificationService.sendNotification(d.getUser(), msg, "/donor/requests");
                if (req.getUrgency() == UrgencyLevel.EMERGENCY) {
                    notificationService.sendEmailSafe(
                        d.getUser().getEmail(),
                        "CRITICAL: Emergency Blood Request in " + req.getCity(),
                        msg + "\n\nPlease login to Blood Donation Finder to accept this life-saving request."
                    );
                }
            }
        } catch (Exception e) {
            log.warn("Failed to notify some matching donors: {}", e.getMessage());
        }
    }

    @Override
    @Transactional(readOnly = true)
    public BloodRequest getRequestById(Long id) {
        return bloodRequestRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Blood request not found with id: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<BloodRequest> getRequestsByRequester(User requester) {
        return bloodRequestRepository.findByRequesterOrderByCreatedAtDesc(requester);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BloodRequest> getIncomingRequestsForDonor(Donor donor) {
        // Find recipient blood groups that this donor is compatible with
        Set<BloodGroup> compatibleRecipientGroups = BloodCompatibilityUtil.getCompatibleRecipients(donor.getBloodGroup());
        String city = donor.getUser().getCity();

        List<BloodRequest> openRequests = bloodRequestRepository.findMatchingOpenRequests(compatibleRecipientGroups, city);

        // Also fetch any requests already accepted by this donor
        List<BloodRequest> acceptedByMe = bloodRequestRepository.findByAcceptedByOrderByCreatedAtDesc(donor);

        Set<Long> seenIds = new HashSet<>();
        List<BloodRequest> combined = new ArrayList<>();

        for (BloodRequest r : acceptedByMe) {
            if (seenIds.add(r.getId())) combined.add(r);
        }
        for (BloodRequest r : openRequests) {
            if (seenIds.add(r.getId())) combined.add(r);
        }

        return combined;
    }

    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ)
    public BloodRequest acceptRequest(Long requestId, Donor donor) {
        // Concurrency control: verify donor eligibility & availability
        if (!donorService.isEligible(donor)) {
            throw new DonorNotEligibleException("You are not currently eligible to donate blood.");
        }
        if (!donor.isAvailable()) {
            throw new DonorNotEligibleException("Your donor status is currently marked as unavailable.");
        }

        BloodRequest request = getRequestById(requestId);

        // Verify status is still OPEN
        if (request.getStatus() != RequestStatus.OPEN) {
            throw new IllegalStateException("This blood request is no longer open (current status: " + request.getStatus() + "). It may have already been accepted by another donor.");
        }

        // Verify compatibility
        if (!BloodCompatibilityUtil.isCompatible(donor.getBloodGroup(), request.getBloodGroup())) {
            throw new IllegalArgumentException("Your blood group (" + donor.getBloodGroup().getLabel() + ") is not compatible with requested group (" + request.getBloodGroup().getLabel() + ").");
        }

        // Assign acceptance and save within version check
        request.setAcceptedBy(donor);
        request.setStatus(RequestStatus.ACCEPTED);
        BloodRequest updated = bloodRequestRepository.save(request);

        // Record response
        RequestResponse resp = new RequestResponse(request, donor, "ACCEPTED");
        requestResponseRepository.save(resp);

        // Send notifications
        notificationService.sendNotification(
            request.getRequester(),
            "Donor " + donor.getUser().getName() + " (" + donor.getBloodGroup().getLabel() + ") has accepted your blood request for " + request.getPatientName() + "! Contact: " + donor.getUser().getPhone(),
            "/requester/requests"
        );
        notificationService.sendNotification(
            donor.getUser(),
            "You have accepted blood request #" + request.getId() + " for patient " + request.getPatientName() + " at " + request.getHospitalName() + ". Contact: " + request.getContactNumber(),
            "/donor/requests"
        );

        log.info("Request #{} accepted by donor {} ({})", requestId, donor.getUser().getName(), donor.getBloodGroup());
        return updated;
    }

    @Override
    @Transactional
    public void rejectRequest(Long requestId, Donor donor) {
        BloodRequest request = getRequestById(requestId);
        RequestResponse resp = new RequestResponse(request, donor, "REJECTED");
        requestResponseRepository.save(resp);
        log.info("Donor {} declined request #{}", donor.getUser().getEmail(), requestId);
    }

    @Override
    @Transactional
    public BloodRequest fulfillRequest(Long requestId, User actor, String remarks) {
        BloodRequest request = getRequestById(requestId);

        // Only requester, authorized hospital or admin can confirm fulfillment
        boolean isOwner = request.getRequester().getId().equals(actor.getId());
        boolean isHospital = actor.getRole() == Role.HOSPITAL;
        boolean isAdmin = actor.getRole() == Role.ADMIN;

        if (!isOwner && !isHospital && !isAdmin) {
            throw new UnauthorizedActionException("You are not authorized to mark this request as fulfilled.");
        }

        if (request.getStatus() != RequestStatus.ACCEPTED && request.getStatus() != RequestStatus.OPEN) {
            throw new IllegalStateException("Only OPEN or ACCEPTED requests can be marked as fulfilled.");
        }

        request.setStatus(RequestStatus.FULFILLED);
        BloodRequest savedRequest = bloodRequestRepository.save(request);

        Donor donor = request.getAcceptedBy();
        if (donor != null) {
            // Update donor stats
            donor.setLastDonationDate(LocalDate.now());
            donor.setTotalDonations(donor.getTotalDonations() + 1);
            donorRepository.save(donor);

            // Create donation record
            DonationRecord record = new DonationRecord(
                donor,
                savedRequest,
                LocalDate.now(),
                request.getUnitsNeeded(),
                request.getHospitalName(),
                remarks != null ? remarks : "Transfusion verified for patient " + request.getPatientName()
            );
            donationRecordRepository.save(record);

            // Notify donor
            notificationService.sendNotification(
                donor.getUser(),
                "Thank you! Your donation for blood request #" + request.getId() + " has been verified and marked as fulfilled. You saved a life!",
                "/donor/history"
            );
        }

        // Notify requester
        notificationService.sendNotification(
            request.getRequester(),
            "Blood request #" + request.getId() + " for patient " + request.getPatientName() + " has been marked as FULFILLED.",
            "/requester/requests"
        );

        log.info("Request #{} fulfilled by actor {}", requestId, actor.getEmail());
        return savedRequest;
    }

    @Override
    @Transactional
    public BloodRequest cancelRequest(Long requestId, User actor) {
        BloodRequest request = getRequestById(requestId);

        boolean isOwner = request.getRequester().getId().equals(actor.getId());
        boolean isAdmin = actor.getRole() == Role.ADMIN;

        if (!isOwner && !isAdmin) {
            throw new UnauthorizedActionException("Only the request owner or an administrator can cancel this request.");
        }

        if (request.getStatus() == RequestStatus.FULFILLED) {
            throw new IllegalStateException("Fulfilled requests cannot be cancelled.");
        }

        request.setStatus(RequestStatus.CANCELLED);
        BloodRequest saved = bloodRequestRepository.save(request);

        if (request.getAcceptedBy() != null) {
            notificationService.sendNotification(
                request.getAcceptedBy().getUser(),
                "Blood request #" + request.getId() + " which you accepted has been CANCELLED by the requester.",
                "/donor/requests"
            );
        }

        log.info("Request #{} cancelled by user {}", requestId, actor.getEmail());
        return saved;
    }

    @Override
    @Scheduled(cron = "0 0 1 * * ?") // Runs daily at 1:00 AM
    @Transactional
    public int expirePastRequests() {
        LocalDate today = LocalDate.now();
        List<BloodRequest> expiredList = bloodRequestRepository.findByStatusAndRequiredByBefore(RequestStatus.OPEN, today);
        for (BloodRequest req : expiredList) {
            req.setStatus(RequestStatus.EXPIRED);
            bloodRequestRepository.save(req);
            notificationService.sendNotification(
                req.getRequester(),
                "Your blood request #" + req.getId() + " for " + req.getPatientName() + " has expired.",
                "/requester/requests"
            );
        }
        if (!expiredList.isEmpty()) {
            log.info("Auto-expired {} past-due blood requests.", expiredList.size());
        }
        return expiredList.size();
    }

    @Override
    @Transactional(readOnly = true)
    public List<BloodRequest> getAllRequests() {
        return bloodRequestRepository.findAllOrderedByUrgency();
    }

    @Override
    @Transactional(readOnly = true)
    public List<BloodRequest> getOpenRequests() {
        return bloodRequestRepository.findByStatus(RequestStatus.OPEN);
    }

    @Override
    @Transactional(readOnly = true)
    public String exportRequestsToCsv() {
        List<BloodRequest> requests = bloodRequestRepository.findAllOrderedByUrgency();
        StringBuilder csv = new StringBuilder();
        csv.append("Request ID,Patient Name,Blood Group,Units,Hospital,City,Area,Urgency,Required By,Status,Requester Name,Requester Phone,Accepted Donor,Created At\n");

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        for (BloodRequest r : requests) {
            String donorName = r.getAcceptedBy() != null ? r.getAcceptedBy().getUser().getName() : "None";
            csv.append(r.getId()).append(",")
               .append("\"").append(r.getPatientName().replace("\"", "\"\"")).append("\",")
               .append(r.getBloodGroup().getLabel()).append(",")
               .append(r.getUnitsNeeded()).append(",")
               .append("\"").append(r.getHospitalName().replace("\"", "\"\"")).append("\",")
               .append("\"").append(r.getCity()).append("\",")
               .append("\"").append(r.getArea() != null ? r.getArea() : "").append("\",")
               .append(r.getUrgency().name()).append(",")
               .append(r.getRequiredBy()).append(",")
               .append(r.getStatus().name()).append(",")
               .append("\"").append(r.getRequester().getName().replace("\"", "\"\"")).append("\",")
               .append(r.getContactNumber()).append(",")
               .append("\"").append(donorName.replace("\"", "\"\"")).append("\",")
               .append(r.getCreatedAt().format(dtf)).append("\n");
        }
        return csv.toString();
    }

    @Override
    @Transactional(readOnly = true)
    public long getTotalRequestCount() {
        return bloodRequestRepository.count();
    }

    @Override
    @Transactional(readOnly = true)
    public long getEmergencyRequestCount() {
        return bloodRequestRepository.countByUrgency(UrgencyLevel.EMERGENCY);
    }

    @Override
    @Transactional(readOnly = true)
    public long getFulfilledRequestCount() {
        return bloodRequestRepository.countByStatus(RequestStatus.FULFILLED);
    }
}
