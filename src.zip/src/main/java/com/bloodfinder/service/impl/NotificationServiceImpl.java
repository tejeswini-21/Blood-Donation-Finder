package com.bloodfinder.service.impl;

import com.bloodfinder.entity.Notification;
import com.bloodfinder.entity.User;
import com.bloodfinder.repository.NotificationRepository;
import com.bloodfinder.service.NotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class NotificationServiceImpl implements NotificationService {

    private static final Logger log = LoggerFactory.getLogger(NotificationServiceImpl.class);

    private final NotificationRepository notificationRepository;

    @Autowired(required = false)
    private JavaMailSender mailSender;

    public NotificationServiceImpl(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    @Override
    @Transactional
    public Notification sendNotification(User user, String message, String linkUrl) {
        Notification notif = new Notification(user, message, linkUrl);
        return notificationRepository.save(notif);
    }

    @Override
    @Transactional
    public Notification sendNotification(User user, String message) {
        return sendNotification(user, message, null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Notification> getUserNotifications(User user) {
        return notificationRepository.findByUserOrderByCreatedAtDesc(user);
    }

    @Override
    @Transactional(readOnly = true)
    public long getUnreadCount(User user) {
        return notificationRepository.countByUserAndReadFalse(user);
    }

    @Override
    @Transactional
    public void markAsRead(Long notificationId, User user) {
        notificationRepository.findById(notificationId).ifPresent(n -> {
            if (n.getUser().getId().equals(user.getId())) {
                n.setRead(true);
                notificationRepository.save(n);
            }
        });
    }

    @Override
    @Transactional
    public void markAllAsRead(User user) {
        List<Notification> unread = notificationRepository.findByUserAndReadFalseOrderByCreatedAtDesc(user);
        for (Notification n : unread) {
            n.setRead(true);
        }
        notificationRepository.saveAll(unread);
    }

    @Override
    public void sendEmailSafe(String toEmail, String subject, String body) {
        if (mailSender == null) {
            log.debug("Mail sender not configured. Skipping email to {}: {}", toEmail, subject);
            return;
        }

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(toEmail);
            message.setSubject(subject);
            message.setText(body);
            message.setFrom("no-reply@bloodfinder.com");
            mailSender.send(message);
            log.info("Email notification sent successfully to {}", toEmail);
        } catch (Exception ex) {
            log.warn("Could not dispatch email to {}: {}. Proceeding normally.", toEmail, ex.getMessage());
        }
    }
}
