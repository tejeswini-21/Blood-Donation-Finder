package com.bloodfinder.service.impl;

import com.bloodfinder.entity.DonationRecord;
import com.bloodfinder.entity.Donor;
import com.bloodfinder.repository.DonationRecordRepository;
import com.bloodfinder.service.DonationRecordService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class DonationRecordServiceImpl implements DonationRecordService {

    private final DonationRecordRepository donationRecordRepository;

    public DonationRecordServiceImpl(DonationRecordRepository donationRecordRepository) {
        this.donationRecordRepository = donationRecordRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<DonationRecord> getHistoryForDonor(Donor donor) {
        return donationRecordRepository.findByDonorOrderByDonationDateDesc(donor);
    }

    @Override
    @Transactional
    public DonationRecord saveRecord(DonationRecord record) {
        return donationRecordRepository.save(record);
    }

    @Override
    @Transactional(readOnly = true)
    public long getTotalDonationsCount() {
        return donationRecordRepository.count();
    }
}
