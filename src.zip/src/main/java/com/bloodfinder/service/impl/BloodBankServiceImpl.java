package com.bloodfinder.service.impl;

import com.bloodfinder.entity.BloodBank;
import com.bloodfinder.entity.BloodStock;
import com.bloodfinder.entity.User;
import com.bloodfinder.enums.BloodGroup;
import com.bloodfinder.exception.ResourceNotFoundException;
import com.bloodfinder.repository.BloodBankRepository;
import com.bloodfinder.repository.BloodStockRepository;
import com.bloodfinder.service.BloodBankService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class BloodBankServiceImpl implements BloodBankService {

    private static final Logger log = LoggerFactory.getLogger(BloodBankServiceImpl.class);

    private final BloodBankRepository bloodBankRepository;
    private final BloodStockRepository bloodStockRepository;

    @Value("${app.stock.low-threshold:5}")
    private int lowStockThreshold;

    public BloodBankServiceImpl(BloodBankRepository bloodBankRepository,
                                BloodStockRepository bloodStockRepository) {
        this.bloodBankRepository = bloodBankRepository;
        this.bloodStockRepository = bloodStockRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public BloodBank getBankById(Long id) {
        return bloodBankRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Blood bank not found with id: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<BloodBank> findBankByHospitalUser(User user) {
        return bloodBankRepository.findByHospitalUser(user);
    }

    @Override
    @Transactional(readOnly = true)
    public BloodBank getBankByHospitalUser(User user) {
        return bloodBankRepository.findByHospitalUser(user)
            .orElseThrow(() -> new ResourceNotFoundException("Blood bank profile not found for user: " + user.getEmail()));
    }

    @Override
    @Transactional(readOnly = true)
    public List<BloodBank> getAllBanks() {
        return bloodBankRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<BloodBank> getVerifiedBanks() {
        return bloodBankRepository.findByVerifiedTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public List<BloodBank> getBanksByCity(String city) {
        if (city == null || city.isBlank()) {
            return bloodBankRepository.findAll();
        }
        return bloodBankRepository.findByCityIgnoreCase(city.trim());
    }

    @Override
    @Transactional
    public void verifyBank(Long bankId, boolean verify) {
        BloodBank bank = getBankById(bankId);
        bank.setVerified(verify);
        bloodBankRepository.save(bank);
        if (bank.getHospitalUser() != null) {
            bank.getHospitalUser().setVerified(verify);
        }
        log.info("Set verification for blood bank {} to {}", bankId, verify);
    }

    @Override
    @Transactional
    public BloodStock updateStock(Long bankId, BloodGroup bloodGroup, int units) {
        if (units < 0) {
            throw new IllegalArgumentException("Available units cannot be negative. Provided: " + units);
        }

        BloodBank bank = getBankById(bankId);
        BloodStock stock = bloodStockRepository.findByBloodBankAndBloodGroup(bank, bloodGroup)
            .orElseGet(() -> new BloodStock(bank, bloodGroup, 0));

        stock.setUnitsAvailable(units);
        stock.setLastUpdated(LocalDateTime.now());
        BloodStock saved = bloodStockRepository.save(stock);
        log.info("Updated blood stock for bank '{}' (group: {}, units: {})", bank.getName(), bloodGroup.getLabel(), units);
        return saved;
    }

    @Override
    @Transactional(readOnly = true)
    public List<BloodStock> getStockForBank(BloodBank bank) {
        return bloodStockRepository.findByBloodBank(bank);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BloodStock> searchAvailableStock(String city, BloodGroup bloodGroup) {
        String cityParam = (city != null && !city.isBlank()) ? city.trim() : null;
        return bloodStockRepository.searchAvailableStock(cityParam, bloodGroup);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BloodStock> getLowStockAlerts(Long bankId) {
        return bloodStockRepository.findLowStockForBank(bankId, lowStockThreshold);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BloodStock> getAllLowStockAlerts() {
        return bloodStockRepository.findAllLowStock(lowStockThreshold);
    }

    @Override
    @Transactional(readOnly = true)
    public long getTotalBloodBanks() {
        return bloodBankRepository.count();
    }

    @Override
    @Transactional(readOnly = true)
    public long getTotalAvailableUnits() {
        return bloodStockRepository.findAll().stream()
            .mapToLong(BloodStock::getUnitsAvailable)
            .sum();
    }
}
