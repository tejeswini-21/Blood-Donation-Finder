package com.bloodfinder.repository;

import com.bloodfinder.entity.BloodBank;
import com.bloodfinder.entity.BloodStock;
import com.bloodfinder.enums.BloodGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface BloodStockRepository extends JpaRepository<BloodStock, Long> {
    Optional<BloodStock> findByBloodBankAndBloodGroup(BloodBank bloodBank, BloodGroup bloodGroup);
    List<BloodStock> findByBloodBank(BloodBank bloodBank);
    List<BloodStock> findByBloodGroup(BloodGroup bloodGroup);

    @Query("SELECT bs FROM BloodStock bs WHERE bs.bloodBank.id = :bankId AND bs.unitsAvailable < :threshold")
    List<BloodStock> findLowStockForBank(@Param("bankId") Long bankId, @Param("threshold") int threshold);

    @Query("SELECT bs FROM BloodStock bs WHERE bs.unitsAvailable < :threshold")
    List<BloodStock> findAllLowStock(@Param("threshold") int threshold);

    @Query("SELECT bs FROM BloodStock bs JOIN bs.bloodBank bb WHERE (:city IS NULL OR LOWER(bb.city) = LOWER(:city)) AND (:bloodGroup IS NULL OR bs.bloodGroup = :bloodGroup) AND bs.unitsAvailable > 0")
    List<BloodStock> searchAvailableStock(@Param("city") String city, @Param("bloodGroup") BloodGroup bloodGroup);
}
