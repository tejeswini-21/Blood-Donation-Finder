package com.bloodfinder.repository;

import com.bloodfinder.entity.User;
import com.bloodfinder.enums.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    boolean existsByEmail(String email);
    List<User> findByRole(Role role);
    long countByRole(Role role);
    List<User> findByVerifiedFalse();
    long countByVerifiedFalse();
    List<User> findByCityIgnoreCase(String city);
}
