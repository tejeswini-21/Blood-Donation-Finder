package com.bloodfinder.repository;

import com.bloodfinder.entity.DonationRecord;
import com.bloodfinder.entity.Donor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DonationRecordRepository extends JpaRepository<DonationRecord, Long> {
    List<DonationRecord> findByDonorOrderByDonationDateDesc(Donor donor);
    long countByDonor(Donor donor);
}
