package com.bloodfinder.repository;

import com.bloodfinder.entity.BloodBank;
import com.bloodfinder.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface BloodBankRepository extends JpaRepository<BloodBank, Long> {
    List<BloodBank> findByCityIgnoreCase(String city);
    List<BloodBank> findByVerifiedTrue();
    Optional<BloodBank> findByHospitalUser(User hospitalUser);
    Optional<BloodBank> findByHospitalUserId(Long userId);
    long countByVerifiedTrue();
}
