package com.bloodfinder.repository;

import com.bloodfinder.entity.Donor;
import com.bloodfinder.entity.User;
import com.bloodfinder.enums.BloodGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface DonorRepository extends JpaRepository<Donor, Long> {
    Optional<Donor> findByUser(User user);
    Optional<Donor> findByUserId(Long userId);
    List<Donor> findByBloodGroupIn(Collection<BloodGroup> bloodGroups);
    long countByAvailableTrue();
    long countByBloodGroup(BloodGroup bloodGroup);

    @Query("SELECT d FROM Donor d JOIN d.user u WHERE d.bloodGroup IN :bloodGroups AND u.enabled = true AND u.verified = true AND d.available = true")
    List<Donor> findActiveEligibleDonors(@Param("bloodGroups") Collection<BloodGroup> bloodGroups);

    @Query("SELECT d FROM Donor d JOIN d.user u WHERE d.bloodGroup IN :bloodGroups AND LOWER(u.city) = LOWER(:city) AND u.enabled = true AND u.verified = true AND d.available = true")
    List<Donor> findActiveEligibleDonorsByCity(@Param("bloodGroups") Collection<BloodGroup> bloodGroups, @Param("city") String city);
}
