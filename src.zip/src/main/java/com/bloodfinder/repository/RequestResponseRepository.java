package com.bloodfinder.repository;

import com.bloodfinder.entity.BloodRequest;
import com.bloodfinder.entity.Donor;
import com.bloodfinder.entity.RequestResponse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface RequestResponseRepository extends JpaRepository<RequestResponse, Long> {
    List<RequestResponse> findByRequest(BloodRequest request);
    Optional<RequestResponse> findByRequestAndDonor(BloodRequest request, Donor donor);
    boolean existsByRequestAndDonor(BloodRequest request, Donor donor);
}
