package com.bloodfinder.repository;

import com.bloodfinder.entity.BloodRequest;
import com.bloodfinder.entity.Donor;
import com.bloodfinder.entity.User;
import com.bloodfinder.enums.BloodGroup;
import com.bloodfinder.enums.RequestStatus;
import com.bloodfinder.enums.UrgencyLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

@Repository
public interface BloodRequestRepository extends JpaRepository<BloodRequest, Long> {
    List<BloodRequest> findByRequesterOrderByCreatedAtDesc(User requester);
    List<BloodRequest> findByStatus(RequestStatus status);
    List<BloodRequest> findByAcceptedBy(Donor donor);
    List<BloodRequest> findByAcceptedByOrderByCreatedAtDesc(Donor donor);

    long countByStatus(RequestStatus status);
    long countByUrgency(UrgencyLevel urgency);

    boolean existsByRequesterAndPatientNameIgnoreCaseAndBloodGroupAndStatus(
        User requester, String patientName, BloodGroup bloodGroup, RequestStatus status
    );

    List<BloodRequest> findByStatusAndRequiredByBefore(RequestStatus status, LocalDate date);

    @Query("SELECT r FROM BloodRequest r WHERE r.status = 'OPEN' AND r.bloodGroup IN :compatibleGroups AND (LOWER(r.city) = LOWER(:city) OR :city IS NULL) ORDER BY CASE WHEN r.urgency = 'EMERGENCY' THEN 1 WHEN r.urgency = 'URGENT' THEN 2 ELSE 3 END, r.createdAt DESC")
    List<BloodRequest> findMatchingOpenRequests(@Param("compatibleGroups") Collection<BloodGroup> compatibleGroups, @Param("city") String city);

    @Query("SELECT r FROM BloodRequest r ORDER BY CASE WHEN r.urgency = 'EMERGENCY' THEN 1 WHEN r.urgency = 'URGENT' THEN 2 ELSE 3 END, r.createdAt DESC")
    List<BloodRequest> findAllOrderedByUrgency();
}
