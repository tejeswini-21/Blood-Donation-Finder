package com.bloodfinder.util;

import com.bloodfinder.enums.BloodGroup;
import java.util.*;

/**
 * Utility class for Red Blood Cell (RBC) compatibility matching rules.
 * 
 * Medical Disclaimer: These rules are for red blood cell compatibility matching only.
 * Final compatibility and donation suitability must always be confirmed by qualified
 * medical professionals and blood bank testing (cross-matching).
 */
public final class BloodCompatibilityUtil {

    private static final Map<BloodGroup, Set<BloodGroup>> COMPATIBLE_DONORS_MAP = new EnumMap<>(BloodGroup.class);
    private static final Map<BloodGroup, Set<BloodGroup>> COMPATIBLE_RECIPIENTS_MAP = new EnumMap<>(BloodGroup.class);

    static {
        // Required: A+ -> Compatible Donors: A+, A-, O+, O-
        COMPATIBLE_DONORS_MAP.put(BloodGroup.A_POS, EnumSet.of(
            BloodGroup.A_POS, BloodGroup.A_NEG, BloodGroup.O_POS, BloodGroup.O_NEG
        ));

        // Required: A- -> Compatible Donors: A-, O-
        COMPATIBLE_DONORS_MAP.put(BloodGroup.A_NEG, EnumSet.of(
            BloodGroup.A_NEG, BloodGroup.O_NEG
        ));

        // Required: B+ -> Compatible Donors: B+, B-, O+, O-
        COMPATIBLE_DONORS_MAP.put(BloodGroup.B_POS, EnumSet.of(
            BloodGroup.B_POS, BloodGroup.B_NEG, BloodGroup.O_POS, BloodGroup.O_NEG
        ));

        // Required: B- -> Compatible Donors: B-, O-
        COMPATIBLE_DONORS_MAP.put(BloodGroup.B_NEG, EnumSet.of(
            BloodGroup.B_NEG, BloodGroup.O_NEG
        ));

        // Required: AB+ -> Universal RBC Recipient: All groups
        COMPATIBLE_DONORS_MAP.put(BloodGroup.AB_POS, EnumSet.allOf(BloodGroup.class));

        // Required: AB- -> Compatible Donors: AB-, A-, B-, O-
        COMPATIBLE_DONORS_MAP.put(BloodGroup.AB_NEG, EnumSet.of(
            BloodGroup.AB_NEG, BloodGroup.A_NEG, BloodGroup.B_NEG, BloodGroup.O_NEG
        ));

        // Required: O+ -> Compatible Donors: O+, O-
        COMPATIBLE_DONORS_MAP.put(BloodGroup.O_POS, EnumSet.of(
            BloodGroup.O_POS, BloodGroup.O_NEG
        ));

        // Required: O- -> Universal RBC Donor -> Only O-
        COMPATIBLE_DONORS_MAP.put(BloodGroup.O_NEG, EnumSet.of(
            BloodGroup.O_NEG
        ));

        // Populate reverse mapping: for a donor blood group, which recipient blood groups can receive it?
        for (BloodGroup recipient : BloodGroup.values()) {
            Set<BloodGroup> donors = COMPATIBLE_DONORS_MAP.get(recipient);
            for (BloodGroup donor : donors) {
                COMPATIBLE_RECIPIENTS_MAP.computeIfAbsent(donor, k -> EnumSet.noneOf(BloodGroup.class))
                    .add(recipient);
            }
        }
    }

    private BloodCompatibilityUtil() {
        // Prevent instantiation
    }

    /**
     * Returns the set of compatible donor blood groups for a given recipient (required) blood group.
     *
     * @param recipientGroup the patient's required blood group
     * @return unmodifiable set of compatible donor blood groups
     */
    public static Set<BloodGroup> getCompatibleDonors(BloodGroup recipientGroup) {
        if (recipientGroup == null) {
            return Collections.emptySet();
        }
        return Collections.unmodifiableSet(COMPATIBLE_DONORS_MAP.getOrDefault(recipientGroup, Collections.emptySet()));
    }

    /**
     * Checks if a donor with donorGroup can safely donate red blood cells to a recipient with recipientGroup.
     *
     * @param donorGroup blood group of the potential donor
     * @param recipientGroup blood group required by the recipient
     * @return true if compatible, false otherwise
     */
    public static boolean isCompatible(BloodGroup donorGroup, BloodGroup recipientGroup) {
        if (donorGroup == null || recipientGroup == null) {
            return false;
        }
        Set<BloodGroup> compatibleDonors = COMPATIBLE_DONORS_MAP.get(recipientGroup);
        return compatibleDonors != null && compatibleDonors.contains(donorGroup);
    }

    /**
     * Returns the set of recipient blood groups that can receive red blood cells from this donor.
     *
     * @param donorGroup blood group of the donor
     * @return unmodifiable set of compatible recipient blood groups
     */
    public static Set<BloodGroup> getCompatibleRecipients(BloodGroup donorGroup) {
        if (donorGroup == null) {
            return Collections.emptySet();
        }
        return Collections.unmodifiableSet(COMPATIBLE_RECIPIENTS_MAP.getOrDefault(donorGroup, Collections.emptySet()));
    }

    public static final String MEDICAL_DISCLAIMER =
        "Notice: Red Blood Cell (RBC) compatibility is calculated based on standard ABO/Rh antigens. " +
        "Final compatibility and transfusion suitability must be confirmed through laboratory testing and " +
        "cross-matching by qualified medical professionals.";
}
