package com.bloodfinder.entity;

import com.bloodfinder.enums.BloodGroup;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "blood_stocks",
    uniqueConstraints = {
        @UniqueConstraint(name = "uk_blood_bank_group", columnNames = {"blood_bank_id", "blood_group"})
    },
    indexes = {
        @Index(name = "idx_stock_group", columnList = "blood_group")
    }
)
public class BloodStock {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "blood_bank_id", nullable = false)
    private BloodBank bloodBank;

    @NotNull(message = "Blood group is required")
    @Enumerated(EnumType.STRING)
    @Column(name = "blood_group", nullable = false, length = 20)
    private BloodGroup bloodGroup;

    @NotNull
    @Min(value = 0, message = "Available units cannot be negative")
    @Column(name = "units_available", nullable = false)
    private Integer unitsAvailable = 0;

    @Column(name = "last_updated", nullable = false)
    private LocalDateTime lastUpdated = LocalDateTime.now();

    public BloodStock() {
    }

    public BloodStock(BloodBank bloodBank, BloodGroup bloodGroup, Integer unitsAvailable) {
        this.bloodBank = bloodBank;
        this.bloodGroup = bloodGroup;
        this.unitsAvailable = unitsAvailable != null ? unitsAvailable : 0;
        this.lastUpdated = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public BloodBank getBloodBank() {
        return bloodBank;
    }

    public void setBloodBank(BloodBank bloodBank) {
        this.bloodBank = bloodBank;
    }

    public BloodGroup getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(BloodGroup bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public Integer getUnitsAvailable() {
        return unitsAvailable;
    }

    public void setUnitsAvailable(Integer unitsAvailable) {
        this.unitsAvailable = unitsAvailable;
    }

    public LocalDateTime getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(LocalDateTime lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public boolean isLowStock() {
        return this.unitsAvailable != null && this.unitsAvailable < 5;
    }
}
