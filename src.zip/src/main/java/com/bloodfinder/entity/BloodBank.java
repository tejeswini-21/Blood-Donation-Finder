package com.bloodfinder.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;

@Entity
@Table(name = "blood_banks", indexes = {
    @Index(name = "idx_bank_city", columnList = "city"),
    @Index(name = "idx_bank_verified", columnList = "verified")
})
public class BloodBank {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Blood bank name is required")
    @Column(nullable = false, length = 120)
    private String name;

    @NotBlank(message = "City is required")
    @Column(nullable = false, length = 60)
    private String city;

    @Column(length = 100)
    private String area;

    @NotBlank(message = "Phone number is required")
    @Column(nullable = false, length = 20)
    private String phone;

    @Column(length = 200)
    private String address;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "hospital_user_id")
    private User hospitalUser;

    @Column(nullable = false)
    private boolean verified = false;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public BloodBank() {
    }

    public BloodBank(String name, String city, String area, String phone, String address, User hospitalUser, boolean verified) {
        this.name = name;
        this.city = city;
        this.area = area;
        this.phone = phone;
        this.address = address;
        this.hospitalUser = hospitalUser;
        this.verified = verified;
        this.createdAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public User getHospitalUser() {
        return hospitalUser;
    }

    public void setHospitalUser(User hospitalUser) {
        this.hospitalUser = hospitalUser;
    }

    public boolean isVerified() {
        return verified;
    }

    public void setVerified(boolean verified) {
        this.verified = verified;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
