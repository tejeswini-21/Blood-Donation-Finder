package com.bloodfinder.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
@Table(name = "donation_records", indexes = {
    @Index(name = "idx_donation_donor", columnList = "donor_id"),
    @Index(name = "idx_donation_date", columnList = "donation_date")
})
public class DonationRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "donor_id", nullable = false)
    private Donor donor;

    /**
     * Optional because walk-in / historical donations may exist without an in-app BloodRequest.
     * Must remain optional=true so Hibernate does not treat a null FK as a transient BloodRequest.
     */
    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "request_id", nullable = true)
    private BloodRequest request;

    @NotNull(message = "Donation date is required")
    @Column(name = "donation_date", nullable = false)
    private LocalDate donationDate;

    @NotNull
    @Min(value = 1, message = "At least 1 unit must be donated")
    @Column(nullable = false)
    private Integer units = 1;

    @NotBlank(message = "Hospital name is required")
    @Column(nullable = false, length = 120)
    private String hospital;

    @Column(length = 255)
    private String remarks;

    public DonationRecord() {
    }

    public DonationRecord(Donor donor, BloodRequest request, LocalDate donationDate, Integer units, String hospital, String remarks) {
        this.donor = donor;
        this.request = request;
        this.donationDate = donationDate;
        this.units = units != null ? units : 1;
        this.hospital = hospital;
        this.remarks = remarks;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Donor getDonor() {
        return donor;
    }

    public void setDonor(Donor donor) {
        this.donor = donor;
    }

    public BloodRequest getRequest() {
        return request;
    }

    public void setRequest(BloodRequest request) {
        this.request = request;
    }

    public LocalDate getDonationDate() {
        return donationDate;
    }

    public void setDonationDate(LocalDate donationDate) {
        this.donationDate = donationDate;
    }

    public Integer getUnits() {
        return units;
    }

    public void setUnits(Integer units) {
        this.units = units;
    }

    public String getHospital() {
        return hospital;
    }

    public void setHospital(String hospital) {
        this.hospital = hospital;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
