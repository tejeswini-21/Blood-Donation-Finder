package com.bloodfinder.entity;

import com.bloodfinder.enums.BloodGroup;
import com.bloodfinder.enums.RequestStatus;
import com.bloodfinder.enums.UrgencyLevel;
import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "blood_requests", indexes = {
    @Index(name = "idx_request_status", columnList = "status"),
    @Index(name = "idx_request_blood_group", columnList = "bloodGroup"),
    @Index(name = "idx_request_city", columnList = "city"),
    @Index(name = "idx_request_urgency", columnList = "urgency"),
    @Index(name = "idx_request_required_by", columnList = "requiredBy")
})
public class BloodRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "requester_id", nullable = false)
    private User requester;

    @NotBlank(message = "Patient name is required")
    @Column(nullable = false, length = 100)
    private String patientName;

    @NotNull(message = "Blood group is required")
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private BloodGroup bloodGroup;

    @NotNull(message = "Units needed is required")
    @Min(value = 1, message = "At least 1 unit is required")
    @Max(value = 10, message = "Maximum 10 units allowed per single request")
    @Column(nullable = false)
    private Integer unitsNeeded;

    @NotBlank(message = "Hospital name is required")
    @Column(nullable = false, length = 120)
    private String hospitalName;

    @NotBlank(message = "City is required")
    @Column(nullable = false, length = 60)
    private String city;

    @Column(length = 100)
    private String area;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private UrgencyLevel urgency = UrgencyLevel.NORMAL;

    @NotNull(message = "Required-by date is required")
    @Column(nullable = false)
    private LocalDate requiredBy;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private RequestStatus status = RequestStatus.OPEN;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "accepted_by_donor_id")
    private Donor acceptedBy;

    @NotBlank(message = "Contact number is required")
    @Column(nullable = false, length = 20)
    private String contactNumber;

    @Column(length = 500)
    private String notes;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    /**
     * Optimistic lock. Must start as null so Spring Data treats the entity as new
     * (persist) rather than calling merge() on a transient instance.
     */
    @Version
    @Column(nullable = false)
    private Long version;

    public BloodRequest() {
    }

    public BloodRequest(User requester, String patientName, BloodGroup bloodGroup, Integer unitsNeeded,
                        String hospitalName, String city, String area, UrgencyLevel urgency,
                        LocalDate requiredBy, String contactNumber, String notes) {
        this.requester = requester;
        this.patientName = patientName;
        this.bloodGroup = bloodGroup;
        this.unitsNeeded = unitsNeeded;
        this.hospitalName = hospitalName;
        this.city = city;
        this.area = area;
        this.urgency = urgency;
        this.requiredBy = requiredBy;
        this.status = RequestStatus.OPEN;
        this.contactNumber = contactNumber;
        this.notes = notes;
        this.createdAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getRequester() {
        return requester;
    }

    public void setRequester(User requester) {
        this.requester = requester;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public BloodGroup getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(BloodGroup bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public Integer getUnitsNeeded() {
        return unitsNeeded;
    }

    public void setUnitsNeeded(Integer unitsNeeded) {
        this.unitsNeeded = unitsNeeded;
    }

    public String getHospitalName() {
        return hospitalName;
    }

    public void setHospitalName(String hospitalName) {
        this.hospitalName = hospitalName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public UrgencyLevel getUrgency() {
        return urgency;
    }

    public void setUrgency(UrgencyLevel urgency) {
        this.urgency = urgency;
    }

    public LocalDate getRequiredBy() {
        return requiredBy;
    }

    public void setRequiredBy(LocalDate requiredBy) {
        this.requiredBy = requiredBy;
    }

    public RequestStatus getStatus() {
        return status;
    }

    public void setStatus(RequestStatus status) {
        this.status = status;
    }

    public Donor getAcceptedBy() {
        return acceptedBy;
    }

    public void setAcceptedBy(Donor acceptedBy) {
        this.acceptedBy = acceptedBy;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }
}
