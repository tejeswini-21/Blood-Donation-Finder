package com.bloodfinder.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "request_responses", indexes = {
    @Index(name = "idx_resp_request", columnList = "request_id"),
    @Index(name = "idx_resp_donor", columnList = "donor_id")
})
public class RequestResponse {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "request_id", nullable = false)
    private BloodRequest request;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "donor_id", nullable = false)
    private Donor donor;

    @NotBlank
    @Column(name = "response_status", nullable = false, length = 20)
    private String responseStatus; // "ACCEPTED", "REJECTED"

    @Column(name = "response_date", nullable = false)
    private LocalDateTime responseDate = LocalDateTime.now();

    public RequestResponse() {
    }

    public RequestResponse(BloodRequest request, Donor donor, String responseStatus) {
        this.request = request;
        this.donor = donor;
        this.responseStatus = responseStatus;
        this.responseDate = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public BloodRequest getRequest() {
        return request;
    }

    public void setRequest(BloodRequest request) {
        this.request = request;
    }

    public Donor getDonor() {
        return donor;
    }

    public void setDonor(Donor donor) {
        this.donor = donor;
    }

    public String getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(String responseStatus) {
        this.responseStatus = responseStatus;
    }

    public LocalDateTime getResponseDate() {
        return responseDate;
    }

    public void setResponseDate(LocalDateTime responseDate) {
        this.responseDate = responseDate;
    }
}
