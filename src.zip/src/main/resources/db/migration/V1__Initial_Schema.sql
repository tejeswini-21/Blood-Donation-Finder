-- Flyway Migration V1: Initial Schema for Blood Donation Finder and Emergency Request System

CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL,
    city VARCHAR(60) NOT NULL,
    area VARCHAR(100),
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    verified BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS donors (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE,
    blood_group VARCHAR(20) NOT NULL,
    age INT NOT NULL,
    gender VARCHAR(20),
    last_donation_date DATE,
    available BOOLEAN NOT NULL DEFAULT TRUE,
    total_donations INT NOT NULL DEFAULT 0,
    CONSTRAINT fk_donor_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS blood_requests (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    requester_id BIGINT NOT NULL,
    patient_name VARCHAR(100) NOT NULL,
    blood_group VARCHAR(20) NOT NULL,
    units_needed INT NOT NULL,
    hospital_name VARCHAR(120) NOT NULL,
    city VARCHAR(60) NOT NULL,
    area VARCHAR(100),
    urgency VARCHAR(20) NOT NULL DEFAULT 'NORMAL',
    required_by DATE NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
    accepted_by_donor_id BIGINT,
    contact_number VARCHAR(20) NOT NULL,
    notes VARCHAR(500),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version BIGINT NOT NULL DEFAULT 0,
    CONSTRAINT fk_request_requester FOREIGN KEY (requester_id) REFERENCES users(id),
    CONSTRAINT fk_request_accepted_donor FOREIGN KEY (accepted_by_donor_id) REFERENCES donors(id)
);

CREATE TABLE IF NOT EXISTS donation_records (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    donor_id BIGINT NOT NULL,
    request_id BIGINT,
    donation_date DATE NOT NULL,
    units INT NOT NULL DEFAULT 1,
    hospital VARCHAR(120) NOT NULL,
    remarks VARCHAR(255),
    CONSTRAINT fk_record_donor FOREIGN KEY (donor_id) REFERENCES donors(id),
    CONSTRAINT fk_record_request FOREIGN KEY (request_id) REFERENCES blood_requests(id)
);

CREATE TABLE IF NOT EXISTS blood_banks (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    city VARCHAR(60) NOT NULL,
    area VARCHAR(100),
    phone VARCHAR(20) NOT NULL,
    address VARCHAR(200),
    hospital_user_id BIGINT,
    verified BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_bank_user FOREIGN KEY (hospital_user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS blood_stocks (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    blood_bank_id BIGINT NOT NULL,
    blood_group VARCHAR(20) NOT NULL,
    units_available INT NOT NULL DEFAULT 0,
    last_updated TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_blood_bank_group UNIQUE (blood_bank_id, blood_group),
    CONSTRAINT fk_stock_bank FOREIGN KEY (blood_bank_id) REFERENCES blood_banks(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS notifications (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    message VARCHAR(500) NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    link_url VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS request_responses (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id BIGINT NOT NULL,
    donor_id BIGINT NOT NULL,
    response_status VARCHAR(20) NOT NULL,
    response_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_resp_request FOREIGN KEY (request_id) REFERENCES blood_requests(id) ON DELETE CASCADE,
    CONSTRAINT fk_resp_donor FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_city ON users(city);
CREATE INDEX IF NOT EXISTS idx_donors_bg ON donors(blood_group);
CREATE INDEX IF NOT EXISTS idx_requests_status ON blood_requests(status);
CREATE INDEX IF NOT EXISTS idx_requests_city ON blood_requests(city);
CREATE INDEX IF NOT EXISTS idx_stocks_bg ON blood_stocks(blood_group);
CREATE INDEX IF NOT EXISTS idx_notifs_user ON notifications(user_id);
